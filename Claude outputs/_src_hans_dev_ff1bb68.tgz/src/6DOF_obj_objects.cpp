/*--------------------------------------------------------------------
REEF3D
Copyright 2008-2026 Hans Bihs

This file is part of REEF3D.

REEF3D is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, see <http://www.gnu.org/licenses/>.
--------------------------------------------------------------------
Author: Hans Bihs
--------------------------------------------------------------------*/

#include"6DOF_obj.h"
#include"lexer.h"
#include"ghostcell.h"

void sixdof_obj::objects_create(lexer *p, ghostcell *pgc)
{
    int qn;

    objects_allocate(p,pgc);
	
    entity_count=0;
	
	for(qn=0;qn<p->X110;++qn)
    {
        box(p,pgc,qn);
        ++entity_count;
    }
    
    for(qn=0;qn<p->X131;++qn)
    {
        cylinder_x(p,pgc,qn);
        ++entity_count;
    }
	
	for(qn=0;qn<p->X132;++qn)
    {
        cylinder_y(p,pgc,qn);
        ++entity_count;
    }
	
	for(qn=0;qn<p->X133;++qn)
    {
        cylinder_z(p,pgc,qn);
        ++entity_count;
    }
	
	for(qn=0;qn<p->X153;++qn)
    {
        wedge_sym(p,pgc,qn);
        ++entity_count;
    }
    
    for(qn=0;qn<p->X163;++qn)
    {
        wedge(p,pgc,qn);
        ++entity_count;
    }
    
    for(qn=0;qn<p->X164;++qn)
    {
        hexahedron(p,pgc,qn);
        ++entity_count;
    }
    
    if(p->X170==1)
    {
        tstart[entity_count]=tricount;

        piston(p,pgc,0);
        tricount+=12;
        
        tend[entity_count]=tricount;
        
        
        ++entity_count;
    }
    
    if(p->X172==1)
    {
        tstart[entity_count]=tricount;

        flap_double(p,pgc,0);
        tricount+=28;
        
        tend[entity_count]=tricount;
        
        
        ++entity_count;
    }
    
    if(p->X180==1)
    {
        read_stl(p,pgc);
		++entity_count;
    }


	/*if (entity_count > 1)
	{
		cout<<"Multiple floating bodies are not fully supported yet."<<endl<<endl;
		//pgc->final(true);
	}*/

    if(p->mpirank==0)
	cout<<"Surface triangles: "<<tricount<<endl;
    
    // Initialise STL geometric parameters
	geometry_stl(p,pgc);
    
    // Order Triangles for correct inside/outside orientation
    triangle_switch_ray(p,pgc);
    
    // Refine triangles
    // X 185 1-3: split triangles larger than the grid
    // X 185 4  : adaptive isotropic re-triangulation matching the local grid spacing
    if(p->X185>0 && p->X60!=2 && entity_count>0 && p->X170==0 && p->X171==0 && p->X172==0)
    {
        if(p->X185==4)
        geometry_remesh(p,pgc);
        
        else
        geometry_refinement(p,pgc);
    }

    if(p->mpirank==0)
	cout<<"Refined surface triangles: "<<tricount<<endl;
}

void sixdof_obj::objects_allocate(lexer *p, ghostcell *pgc)
{
    double U,ds,phi,r,snum,trisum;
    
    entity_sum = p->X110 + p->X131 + p->X132 + p->X133 + p->X153 + p->X163 + p->X164 + p->X170 + p->X171 + p->X172;
	tricount=0;
    trisum=0;
    
    // box
    trisum+=12*p->X110;
    
    // cylinder_x   
    r=p->X131_rad;
	U = 2.0 * PI * r;
	ds = 0.75*p->dx;      // segment length 0.75 dx (was 0.75*U*dx, i.e. 1/(0.75 dx) segments for any radius)
	snum = MAX(int(U/ds),8);
	trisum+=5*(snum+1)*p->X131;
    
    // cylinder_y
    r=p->X132_rad;
	U = 2.0 * PI * r;
	ds = 0.75*p->dx;      // segment length 0.75 dx (was 0.75*U*dx, i.e. 1/(0.75 dx) segments for any radius)
	snum = MAX(int(U/ds),8);
	trisum+=5*(snum+1)*p->X132;
    
    // cylinder_z
    r=p->X133_rad;
	U = 2.0 * PI * r;
	ds = 0.75*p->dx;      // segment length 0.75 dx (was 0.75*U*dx, i.e. 1/(0.75 dx) segments for any radius)
	snum = MAX(int(U/ds),8);
    trisum+=5*(snum+1)*p->X133;
    
    // wedge sym
    trisum+=12*p->X153;
    
    // wedge
    trisum+=8*p->X163;
    
    // hexahedron
    trisum+=12*p->X164;
    
    // piston
    trisum+=12*p->X170;
    
    // piston
    trisum+=28*p->X172;
    
    // STL
    if(p->X180==1)
    entity_sum=1;

    
    p->Darray(tri_x,trisum,3);
	p->Darray(tri_y,trisum,3);
	p->Darray(tri_z,trisum,3);
    p->Darray(tri_x0,trisum,3);
	p->Darray(tri_y0,trisum,3);
	p->Darray(tri_z0,trisum,3);    	
    
	p->Iarray(tstart,entity_sum);
	p->Iarray(tend,entity_sum);
}
