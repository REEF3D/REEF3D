/*--------------------------------------------------------------------
REEF3D
Copyright 2008-2026 Hans Bihs

This file is part of REEF3D.

REEF3D is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, see <http://www.gnu.org/licenses/>.
--------------------------------------------------------------------
Author: Hans Bihs
--------------------------------------------------------------------*/

#ifndef BEDLOAD_VR_H_
#define BEDLOAD_VR_H_

#include"bedload.h"
#include"increment.h"

using namespace std;

class bedload_VR final : public bedload, public increment
{
public:

    bedload_VR(lexer*);
    virtual ~bedload_VR();

	void start(lexer*, ghostcell*, sediment_fdm*) override final;

private:
    double rhosed,rhowat,Rstar,Ds;
    double g,d50;
    double visc;
    double shields_eff;
    double shields_crit;
};

#endif


