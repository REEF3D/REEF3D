/*--------------------------------------------------------------------
REEF3D
Copyright 2008-2026 Hans Bihs

This file is part of REEF3D.

REEF3D is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, see <http://www.gnu.org/licenses/>.
--------------------------------------------------------------------
Author: Hans Bihs
--------------------------------------------------------------------*/

#ifndef BEDSLOPE_H_
#define BEDSLOPE_H_

#include"norm_vec.h"
#include"nhflow_gradient.h"

class lexer;
class field;
class ghostcell;
class ddweno_f_nug;
class sediment_fdm;

using namespace std;

class bedslope :  public norm_vec, nhflow_gradient
{
public:
    bedslope(lexer*);
    virtual ~bedslope();
    
    void slope_analytical(lexer*,ghostcell*,sediment_fdm*);
    void slope_cds(lexer*,ghostcell*,sediment_fdm*);
	void slope_weno(lexer*, ghostcell*,sediment_fdm*);
    void slope_weno_topo(lexer*, ghostcell*,sediment_fdm*,field&);
    

private:

    double u_abs,u_plus,dist;
    double uvel, vvel;
    double midphi,delta,beta;
    double alpha0, teta0;
    
    ddweno_f_nug *pdx;
};

#endif


