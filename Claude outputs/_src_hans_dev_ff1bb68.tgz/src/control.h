/*--------------------------------------------------------------------
REEF3D
Copyright 2008-2026 Hans Bihs

This file is part of REEF3D.

REEF3D is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, see <http://www.gnu.org/licenses/>.
--------------------------------------------------------------------
Author: Alexander Hanke
--------------------------------------------------------------------*/

#ifndef CONTROL_H_
#define CONTROL_H_

#include "resize.h"

class lexer;

class control : public virtual resize_class
{
public:
    control() = default;
    virtual ~control() = default;
protected:
    void read_control(lexer*);
    void ctrlsend();
    void ctrlrecv();
    void ini_default();
    void parse(lexer*);
private:
    void clear(char&, int&);
    void missing_parameter();
public:

    // Hydrodynamics Models
    int A10;

    // SFLOW
    int A209,A210,A211,A212,A214,A215,A216,A217,A218,A219,A220,A221,A230,A240,A241,A242,A243,A246,A248;
    int A251,A260;
    double A261,A262,A263,A264;
    int A270,A271,A272,A274,A275,A276,A277,A278,A280,A281;
    double A273,A278_r,A279_L,A279_a;
    double *A276_xs,*A276_xe,*A276_ys,*A276_ye;
    double *A277_xs,*A277_xe,*A277_ys,*A277_ye;
    double A223,A224,A247,A249,A244,A251_val;
    double A250;

    // FNPF
    int A309,A310,A311,A312,A313,A314,A315,A316,A317,A318,A320,A321,A322,A323,A324,A327,A328,A329,A330,A332,A334,A336,A337,A338,A339,A343,A345,A347,A348;
    double A319,A325,A326,A331,A335,A340,A341,A342,A344,A346,A349;
    int A350,A351,A352,A353,A357,A358,A361,A362,A363,A368;
    double A354,A355,A356,A365,A366;
    int A370,A372,A373,A374,A378;
    double A371_u,A371_dir,A375,A376_s,A376_sc,A376_c,A377;
    double A372_xs,A372_xe,A372_ys,A372_ye;
    int A380,A385,A386,A388;
    int A390,A394,A395_dir,A395_off;
    double A391,A392_K,A392_C,A393,A396,A397_E,A397_nu,A398,A399_m,A399_A;
    int A399_seed;
    int A400,A401;
    double A402_L,A402_C,A402_T;
    double A403;
    double A381,A382,A383,A384_mu,A384_e,A387,A389;

    // NSEWAVE
    int A410;
    double A440;

    // NHFLOW
    int A509,A510,A511,A512,A513,A514,A515,A516,A517,A518,A519;
    int A520,A521,A524,A525,A527;
    double A522,A523,A526,A528;
    double A531;
    int A532,A533;
    int A540,A543;
    double A541,A542,A544,A545;
    int A550,A551,A552,A553;
    double A554,A555,A556,A557;
    int A560;
    int A564,A565,A566,A567,A569;
    int A570,A573,A574,A578,A580;
    double A568,A571_u,A571_dir,A575,A576_s,A576_sc,A576_c;
    int A572;
    double A572_xs,A572_xe,A572_ys,A572_ye;
    int A581;
    double *A581_xs,*A581_xe,*A581_ys,*A581_ye,*A581_zs,*A581_ze;
    int A583;
    double *A583_xc,*A583_zc,*A583_ys,*A583_ye,*A583_r;
    int A584;
    double *A584_xc,*A584_yc,*A584_zs,*A584_ze,*A584_r;
    int A585;
    double *A585_xm1, *A585_ym1, *A585_zm1, *A585_r1, *A585_xm2, *A585_ym2, *A585_zm2, *A585_r2;
    int A586;
    double *A586_xm,*A586_ym,*A586_zm,*A586_r;
    int A587;
    double *A587_xs,*A587_xe,*A587_ys,*A587_ye,*A587_zs,*A587_ze;
    int A588;
    double *A588_xs,*A588_xe,*A588_ys,*A588_ye,*A588_zs,*A588_ze;
    int A589;
    double *A589_xs,*A589_xe,*A589_ys,*A589_ye,*A589_zs,*A589_ze;

    int A590,A591,A592,A593,A594,A599;
    double A591_x,A591_y,A591_z;
    double A592_dx,A592_dy,A592_dz;
    double A593_x,A593_y,A593_z,A593_phi,A593_theta,A593_psi;

    // NHFLOW Lagrangian particles
    int L10,L11;
    int L21,L22,L23;
    double *L21_val,*L22_val,*L23_val;
    double L31,L33,L34;
    int L32;
    int L41;
    double L41_u,L41_dir;
    int L51,L52,L53;
    double L61;
    int L62;

    // boundary conditions
    int B10,B11,B20,B21,B22,B23;
    int B30,B32,B33;
    double B31,B32_x,B32_y,B32_z;
    int B60,B61,B71,B75,B76,B77,B84,B85,B81,B82,B86,B87,B89,B90,B91,B92,B93,B94,B97,B98,B99,B101,B105,B106,B107;
    int B136,B138,B138_1,B138_2,B139;
    int B180,B191,B192,B240,B241,B242,B243;
    double B29,B50,B51,B52,B53,B54,B55,B56,B57,B81_1,B81_2,B81_3,B83,B117,B118,B87_1,B87_2,B88;
    double B91_1,B91_2,B93_1,B93_2,B94_wdt,B96_1,B96_2,B102,B105_1,B105_2,B105_3;
    double *B71_val,*B71_dist,*B71_b,*B71_x,*B71_y;
    double *B106_b,*B106_x,*B106_y;
    double *B107_xs,*B107_xe,*B107_ys, *B107_ye, *B107_d;
    int B108;
    double *B108_xs,*B108_xe,*B108_ys, *B108_ye, *B108_d;
    int B110;
    double B110_zs,B110_ze;
    double B111_zs,B111_ze;
    double B112_zs,B112_z2,B112_ze;
    int B113,B113_J,B115,B116,B119,B125,B127;
    double B114_fmin,B114_fmax,B114_f2min;
    double B120,B122,B123,B125_y;
    int B130,B133;
    double B131,B132_s,B132_e;
    double B134,B135;
    int B160, B170;
    int B181,B182,B183;
    double B181_1,B181_2,B181_3,B182_1,B182_2,B182_3,B183_1,B183_2,B183_3;
    double B191_1,B191_2,B191_3,B191_4,B192_1,B192_2,B192_3,B192_4;
    double B194_s,B194_e;
    
    int B200,B201,B208;
    double B201_n, B201_d50, B201_alpha, B201_beta;
    double B209;
    int B210;
    double *B210_xs,*B210_xe,*B210_ys,*B210_ye,*B210_zs,*B210_ze;
    int B212;
    double *B212_xc,*B212_zc,*B212_ys,*B212_ye,*B212_r;
    int B213;
    double *B213_xc,*B213_yc,*B213_zs,*B213_ze,*B213_r;
    int B214;
    double *B214_xm1, *B214_ym1, *B214_zm1, *B214_r1, *B214_xm2, *B214_ym2, *B214_zm2, *B214_r2;
    int B215;
    double *B215_xm,*B215_ym,*B215_zm,*B215_r;
    int B217;
    double *B217_xs,*B217_xe,*B217_ys,*B217_ye,*B217_zs,*B217_ze;
    int B218;
    double *B218_xs,*B218_xe,*B218_ys,*B218_ye,*B218_zs,*B218_ze;
    int B219;
    double *B219_xs,*B219_xe,*B219_ys,*B219_ye,*B219_zs,*B219_ze;
    
    int B230,B231,B232,B233,B234;
    double B231_x,B231_y,B231_z;
    double B232_dx,B232_dy,B232_dz;
    double B233_x,B233_y,B233_z,B233_phi,B233_theta,B233_psi;
    
    double *B240_D, *B240_C, *B240_xs, *B240_xe, *B240_ys, *B240_ye, *B240_zs, *B240_ze;
    double B260,B264,B267;
    int B265;
    int B270;
    double *B270_xs, *B270_xe, *B270_ys, *B270_ye, *B270_zs, *B270_ze, *B270_n, *B270_d50, *B270_alpha, *B270_beta;
    int B274;
    double *B274_xc,*B274_yc,*B274_zs,*B274_ze,*B274_r, *B274_n, *B274_d50, *B274_alpha, *B274_beta;
    int B281;
    double *B281_xs, *B281_xe, *B281_ys, *B281_ye, *B281_zs, *B281_ze, *B281_n, *B281_d50, *B281_alpha, *B281_beta;
    int B282;
    double *B282_xs, *B282_xe, *B282_ys, *B282_ye, *B282_zs, *B282_ze, *B282_n, *B282_d50, *B282_alpha, *B282_beta;
	int B291;
    double *B291_xs, *B291_xe, *B291_ys, *B291_ye, *B291_zs, *B291_ze, *B291_d, *B291_n, *B291_d50, *B291_alpha, *B291_beta;
    int B295;
    int B307,B308,B310,B311;
    double B309;
    double *B310_xs, *B310_xe, *B310_ys, *B310_ye, *B310_zs, *B310_ze, *B310_N, *B310_D, *B310_Cd;
    double *B311_xm, *B311_ym, *B311_r, *B311_zs, *B311ze, *B311_N, *B311_D, *B311_Cd;
    int B321;
    double *B321_xs, *B321_xe, *B321_ys, *B321_ye, *B321_zs, *B321_ze, *B321_N, *B321_D, *B321_Cd;
    int B322;
    double *B322_xs, *B322_xe, *B322_ys, *B322_ye, *B322_zs, *B322_ze, *B322_N, *B322_D, *B322_Cd;

    int B411,B412,B413,B414,B415,B416,B417,B418,B421,B422;
    int *B411_ID;
    double *B411_Q;
    int *B412_ID;
    double *B412_pressBC;
    int *B413_ID;
    double *B413_h;
    int *B414_ID;
    double *B414_Uio;
    int *B415_ID;
    double *B415_U,*B415_V,*B415_W;
    int *B416_ID;
    double *B416_alpha;
    int *B417_ID;
    double *B417_Nx,*B417_Ny,*B417_Nz;
    int *B418_ID;
    int *B418_pio;
    int *B421_ID,*B421_Q;
    int *B422_ID,*B422_FSF;
    int B440;
    int *B440_ID,*B440_face;
    double *B440_xs,*B440_xe,*B440_ys,*B440_ye;
    int B441;
    int *B441_ID,*B441_face;
    double *B441_xs,*B441_xe,*B441_ys,*B441_ye,*B441_zs,*B441_ze;
    int B442;
    int *B442_ID,*B442_face;
    double *B442_xm,*B442_ym,*B442_zm,*B442_r;

    // Concentration Options
    double C1,C2,C3,C4,C5;
    int C9,C10,C15,C20;
    double C50_1,C50_2;
    double C51,C52,C53,C54,C55,C56;
    double C57_1,C57_2,C57_3,C57_4;
    double C58_1,C58_2,C58_3,C58_4;
    int C75;
    double *C75_x,*C75_z,*C75_a,*C75_s,*C75_l,*C75_v;

    // discretization
    int D10,D11,D20,D21,D22,D23,D30,D31,D37;

    // Free Surface
    int F30,F31,F32,F34,F35,F36,F40,F44,F46,F47,F50,F150,F151;
    double F33,F39,F42,F43,F45;
    double F51,F52,F53,F54,F55,F56;
    int F50_flag;
    double F57_1,F57_2,F57_3,F57_4;
    double F58_1,F58_2,F58_3,F58_4;
    double F59_xm, F59_ym, F59_zs, F59_ze, F59_r;
    int F60_flag;
    double F60,F61,F62,F63;
    int F64;
    int F68;
    double F68_x,F68_y,F68_z;
    int F70;
    double *F70_xs, *F70_xe, *F70_ys, *F70_ye, *F70_zs, *F70_ze;
    int F71;
    double *F71_xs, *F71_xe, *F71_ys, *F71_ye, *F71_zs, *F71_ze;
    int F72;
    double *F72_xs, *F72_xe, *F72_ys, *F72_ye, *F72_h;
    int F80,F85;
    double F84;
    int F88,F89,F90;
    double F91;
    int F92;
    double F93, F94, F95;
    int F96;
    double F96_xs,F96_xe;
    int F97;
    double F97_ys,F97_ye;
    int F98;
    int F112;

    int F100;
    double F101_nx,F101_ny,F101_nz,F101_s,F101_e;

    double *F112_xs,*F112_xe,*F112_ys,*F112_ye,*F112_zs,*F112_ze;
    int F113;
    double *F113_xs,*F113_xe,*F113_ys,*F113_ye,*F113_zs,*F113_ze;
    int F114;
    double *F114_xs,*F114_xe,*F114_ys,*F114_ye,*F114_zs,*F114_ze;
    int F115;
    double *F115_xs,*F115_xe,*F115_ys,*F115_ye,*F115_zs,*F115_ze;

    int F300,F305,F310,F350;
    double F321,F322,F323,F360,F361,F362;
    int F369,F370,F371,F374,F375,F378,F379;
    double *F369_x,*F369_z,*F369_a,*F369_s,*F369_l,*F369_v;
    double *F370_xs, *F370_xe, *F370_ys, *F370_ye, *F370_zs, *F370_ze;
    double *F371_xs, *F371_xe, *F371_ys, *F371_ye, *F371_zs, *F371_ze;
    double *F374_xc, *F374_zc, *F374_r;
    double *F375_xc, *F375_zc, *F375_r;
    double *F378_xc, *F378_yc,*F378_zc, *F378_r;
    double *F379_xc, *F379_yc,*F379_zc, *F379_r;
    double F380,F381,F382;
    int F390,F391,F394,F395,F398,F399;
    double *F390_xs, *F390_xe, *F390_ys, *F390_ye, *F390_zs, *F390_ze;
    double *F391_xs, *F391_xe, *F391_ys, *F391_ye, *F391_zs, *F391_ze;
    double *F394_xc, *F394_zc, *F394_r;
    double *F395_xc, *F395_zc, *F395_r;
    double *F398_xc, *F398_yc,*F398_zc, *F398_r;
    double *F399_xc, *F399_yc,*F399_zc, *F399_r;

    // Grid Options
    int G1,G2,G5;
    int G10,G11,G12,G20,G21,G22,G30;
    int G40,G41;

    // Heat Options
    double H1,H2;
    int H3,H4,H9,H10,H15;
    double H4_beta1,H4_beta2,H50_1,H50_2;
    double H51,H52,H53,H54,H55,H56;
    double H57_1,H57_2,H57_3,H57_4;
    double H58_1,H58_2,H58_3,H58_4;
    int H61,H62,H63,H64,H65,H66;
    double H61_T,H62_T,H63_T,H64_T,H65_T,H66_T;

    // Initialize Options
    int I10,I11,I12,I13,I30,I40,I41,I44,I56;
    double I21,I50,I55,I58_1,I58_2;
    int I230;
    double I231,I232,I233;
    int I240;
    double I241;

    // Numerical Options
    int N10,N11,N12,N13,N14,N15,N18,N40,N45,N46,N48,N60;
    int N20,N22,N23,N24,N25,N26;
    double N41,N43,N44,N47,N49,N50,N61;

    // MPI Options
    int M10;

    // Print options
    int P10,P11,P12,P15,P16,P19,P20,P21,P23,P24,P25,P26,P27,P28,P29,P35,P37,P38,P40,P41,P43,P44,P45,P50,P51,P52,P53,P54,P56,P57,P58,P59;
    int P61,P62,P63,P64,P65,P66,P67,P68,P69,P71,P72,P73,P74,P75,P76,P77,P78,P79,P80,P81,P82,P85,P88,P92,P99,P101,P120,P121,P122,P123,P124,P125,P126;
    int P144,P145,P146,P147,P148,P140,P150,P151,P152,P166,P167,P168,P180,P181,P184,P185,P186,P190,P191,P194,P195;
    double P22,P30,P34,P39,P42;
    double *P35_ts,*P35_te,*P35_dt;
    double P43_xs,P43_xe,P43_ys,P43_ye;
    int P46,P46_is,P46_ie;
    int P47,P47_ts,P47_te;
    double *P50_x,*P50_y;
    double *P51_x,*P51_y;
    double *P52_y,*P56_x;
    double P55;
    double *P58_x,*P58_y,*P58_T;
    double *P61_x,*P61_y,*P61_z;
    double *P62_xs,*P62_ys,*P62_zs,*P62_xe,*P62_ye,*P62_ze;
    double *P63_x,*P63_y;
    double *P64_x,*P64_y,*P64_z;
    double *P65_x,*P65_y,*P65_z;
    double *P66_x,*P66_y,*P66_z;
    double *P67_x,*P67_y;
    double *P68_x,*P68_y;
    double *P69_x,*P69_y;
    double *P81_xs,*P81_xe,*P81_ys,*P81_ye,*P81_zs,*P81_ze;
    double *P85_x,*P85_y,*P85_r,*P85_cd,*P85_cm;
    double *P88_x,*P88_y;
    double P91;
    double P101_xm,P101_ym,P101_zs,P101_ze,P101_r1,P101_r2;
    int P110;
    double P111;
    double *P121_x,*P121_y;
    double *P123_y,*P124_x;
    double *P125_x,*P125_y;
    int P131,P132,P133,P134;
    double *P133_y;
    double *P134_y;
    double *P140_x,*P140_y;
    double P141;
    double *P144_xs,*P144_xe,*P144_ys,*P144_ye;
    int *P144_n;
    double *P145_xs,*P145_xe,*P145_ys,*P145_ye,*P145_tbegin,*P145_tend;
    int *P145_n;
    double *P146_y,*P146_tbegin,*P146_tend;
    double *P147_x,*P147_tbegin,*P147_tend;
    double *P148_x,*P148_y,*P148_tbegin,*P148_tend;
    double *P167_x;
    double *P168_x,*P168_zs,*P168_ze;
    double P182,P183;
    int *P184_its,*P184_ite,*P184_dit;
    double *P185_ts,*P185_te,*P185_dt;
    double *P186_tstart,*P186_tend;
    double P192;
    int *P194_its,*P194_ite,*P194_dit;
    double *P195_ts,*P195_te,*P195_dt;
    int P230,P240,P250;
    int P310,P311,P312,P351,P352;
    double *P230_x,*P240_x;
    double *P351_x,*P351_y;
    double *P352_x,*P352_y;

    // DEM
    int E10,E11,E13,E16,E21,E22,E26,E27,E28,E29;
    double E12,E14,E15,E17,E18,E19,E20,E23,E24,E25,E30;

    // Particles
    int Q10;
    int Q11;
    int Q12;
    int Q13;
    int Q20;
    int Q24;
    int Q29;
    int Q43;
    double Q14;
    double Q15;
    double Q16;
    double Q17;
    double Q18;
    double Q26;
    int Q19,Q27,Q28,Q44,Q50,Q51;
    double Q32,Q33,Q34,Q35,Q36,Q37,Q38;
    double Q22;
    double Q23;
    double Q25,Q30,Q45;
    double Q41;
    int Q61,*Q61_i;
    double *Q61_x,*Q61_y,*Q61_z;
    int Q73;
    double *Q73_val,*Q73_dist,*Q73_b,*Q73_x,*Q73_y;

    int Q101;
    double Q102;
    int Q110;
    double *Q110_xs,*Q110_xe,*Q110_ys,*Q110_ye,*Q110_zs,*Q110_ze;
    int Q111;
    double *Q111_xs,*Q111_xe,*Q111_ys,*Q111_ye,*Q111_zs,*Q111_ze;

    int Q120;
    int Q121;
    int Q122;

    int Q180;
    int Q181;
    double Q182;
    int Q183;

    int Q200;
    int Q201;
    int Q202;

    // Sediment Transport
    int S10,S11,S12,S15,S16,S25,S27,S28,S29,S31,S32,S33,S34,S36,S37,S38,S41,S42,S43,S44,S50,S60,S61,S62,S66,S73,S74,S75,S77,S78,S79,S80,S83,S84,S85,S90,S91,S94,S100,S101,S49,S51,S54,S56;
    double S13,S14,S17,S18,S19,S20,S21,S22,S23,S24,S26_a,S26_b,S30,S35,S39,S40,S45,S46,S47,S48,S57,S71,S72,S81,S82,S92,S93,S102,S103,S52,S53,S55;
    double S29_ts,S29_te,S29_dts,S29_dte;
    double *S73_val,*S73_dist,*S73_b,*S73_x,*S73_y;
    double *S74_xs,*S74_xe,*S74_ys,*S74_ye;
    double *S75_x,*S75_dist;
    double *S51_d,*S51_fa,*S51_fs;
    double S77_xs,S77_xe;

    // Turbulence
    int T10,T12,T21,T33,T34,T36,T39,T41,T45;
    double T23,T31,T37,T38,T42,T43,T44;

    // Waterflow
    double W1,W2,W3,W4,W5,W6,W7,W10,W_fb;
    int W11,W12,W13,W14,W15,W16;
    double W11_u,W11_v,W11_w,W12_u,W12_v,W12_w,W13_u,W13_v,W13_w,W14_u,W14_v,W14_w,W15_u,W15_v,W15_w,W16_u,W16_v,W16_w;
    double W20,W21,W22,W31,W29_x,W29_y,W29_z;
    int W30;
    int W41;
    double *W41_xc,*W41_yc,*W41_zs,*W41_ze,*W41_vel,*W41_beta;
    double W50;
    int W50_air;
    int W90;
    double W95,W96,W97,W98;
    int W101;
    double W102_c,W102_phi;
    double W103,W104;
    double W105_tau_00;
    double W105_C_total;
    double W105_C_kaolinite_chlorite;
    double W105_C_illite;
    double W105_C_montmorillonite;
    double W106_b;
    double W106_m_y;
    double W107_mu_min;
    double W107_delta;
    double W107_mu_0;
    double W108_a_2;
    int W110,W111;
    double W112;

    // 6DOF
    int X10,X12,X14,X15,X16,X19,X11_u,X11_v,X11_w,X11_p,X11_q,X11_r,X21,X22,X23,X24,X31,X32,X33,X34,X38;
    int X39,X40,X45,X46,X48,X49,X50,X60,X110,X120,X131,X132,X133;
    int X100,X101,X102,X103,X141,X142,X143,X153,X170,X171,X172;
    int X180,X181,X182,X183,X210,X211;
    int X310, X311, X312, X313, X314, X315, X320, X321;
    int X20;
    double X21_d,X22_m;
    double X16_n,X16_d50,X16_alpha,X16_beta;
    double X23_x,X23_y,X23_z;
    double X24_Ix,X24_Iy,X24_Iz;
    double X25_Cp,X25_Cq,X25_Cr;
    double X26_Cu,X26_Cv,X26_Cw;
    double X41,X42,X43,X44;
    double X100_x,X100_y,X100_z;
    double X101_phi, X101_theta, X101_psi;
    double *X102_u, *X102_v, *X102_w;
    double X103_p, X103_q, X103_r;
    double *X110_xs,*X110_xe,*X110_ys,*X110_ye,*X110_zs,*X110_ze;
    double X120_rad,X120_xc,X120_yc,X120_zc;
    double X131_rad,X131_h,X131_xc,X131_yc,X131_zc;
    double X132_rad,X132_h,X132_xc,X132_yc,X132_zc;
    double X133_rad,X133_h,X133_xc,X133_yc,X133_zc;
    double X153_xs,X153_xe,X153_ys,X153_ye,X153_zs,X153_ze;
    int X163;
    double *X163_x1,*X163_y1,*X163_z1;
    double *X163_x2,*X163_y2,*X163_z2;
    double *X163_x3,*X163_y3,*X163_z3;
    double *X163_x4,*X163_y4,*X163_z4;
    double *X163_x5,*X163_y5,*X163_z5;
    double *X163_x6,*X163_y6,*X163_z6;
    int X164;
    double *X164_x1,*X164_y1,*X164_z1;
    double *X164_x2,*X164_y2,*X164_z2;
    double *X164_x3,*X164_y3,*X164_z3;
    double *X164_x4,*X164_y4,*X164_z4;
    double *X164_x5,*X164_y5,*X164_z5;
    double *X164_x6,*X164_y6,*X164_z6;
    double *X164_x7,*X164_y7,*X164_z7;
    double *X164_x8,*X164_y8,*X164_z8;
    double X170_xs,X170_xe,X170_ys,X170_ye,X170_zs,X170_ze;
    double X171_xs,X171_xe,X171_ys,X171_ye,X171_zs,X171_z1,X171_ze;
    double X172_xs,X172_xe,X172_ys,X172_ye,X172_zs,X172_z1,X172_z2,X172_ze;
    double X181_x,X181_y,X181_z;
    double X182_dx,X182_dy,X182_dz;
    double X183_x,X183_y,X183_z,X183_phi,X183_theta,X183_psi;
    int X184,X185,X188,X189,X190;
    double X186,X187;
    int X205;
    int X206,X207;
    double X206_ts,X206_te,X207_ts,X207_te;
    double X210_u,X210_v,X210_w;
    double X211_p,X211_q,X211_r;
    int X240;
    double X241,X242_x,X242_y,X242_z,X243;
    double *X311_xs,*X311_xe,*X311_ys,*X311_ye,*X311_zs,*X311_ze;
    double *X311_w,*X311_rho_c,*X311_EA,*X311_d,*X311_l,*X311_H,*X311_P,*X311_facT;
    double *X312_k,*X312_T0;
    double *X314_T, *X315_t;
    int *X320_type;
    double *X321_Sn,*X321_d,*X321_lambda,*X321_dk,*X321_rho,*X321_nd,*X321_nl;
    double *X322_D,*X322_L,*X322_x0,*X322_y0,*X322_z0,*X322_phi,*X322_theta,*X322_psi;
    int X324;
    int X330;
    double X323_m,X323_d,X323_l;
    double *X324_x,*X324_y,*X324_z;
    double X325_dt,X325_relX,X325_relY,X325_relZ;
    int X400;
    double X401_p0,X401_cl,X401_cb,X401_a;
    int X410;
    int X500,X501,X502,X503,X504;
    double X501_ax,X501_ay,X501_az,X501_xa,X501_ya,X501_za;
    double X502_B;
    double X503_K,X503_B;
    double X504_qmin,X504_qmax,X504_K,X504_C;

    // FSI
    int Z10,Z11,Z20,Z30;
    double Z21,Z31;
    double *Z11_x,*Z11_y,*Z11_z,*Z11_l,*Z11_w,*Z11_t,*Z11_rho,*Z11_e,*Z11_ix,*Z11_iy,*Z11_iz,*Z11_nu,*Z11_n;
    double Z12_ckx,Z12_cky,Z12_ckz,Z12_cdx,Z12_cdy,Z12_cdz;

    // Grid
    int Y40,Y50,Y60,Y71,Y72,Y73,Y74;

    // Test options
    int Y1,Y2,Y3,Y4,Y5;

    int* ictrl;
    double* dctrl;
    const int ctrlsize = 22500;
protected:
    int dd_send,dd_recv;
    int ii_send,ii_recv;
};
#endif
