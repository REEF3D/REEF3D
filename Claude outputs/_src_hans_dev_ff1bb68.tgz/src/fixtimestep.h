/*--------------------------------------------------------------------
REEF3D
Copyright 2008-2026 Hans Bihs

This file is part of REEF3D.

REEF3D is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, see <http://www.gnu.org/licenses/>.
--------------------------------------------------------------------
Author: Hans Bihs
--------------------------------------------------------------------*/

#ifndef FIXTIMESTEP_H_
#define FIXTIMESTEP_H_

#include"timestep.h"
#include"increment.h"

class turbulence;

using namespace std;

class fixtimestep final : public timestep, public increment
{
public:
	fixtimestep(lexer*);
	virtual ~fixtimestep();
	void start(fdm*,lexer*,ghostcell*,turbulence*) override final;
	void ini(fdm*,lexer*,ghostcell*) override final;


};

#endif

