/*--------------------------------------------------------------------
REEF3D
Copyright 2008-2026 Hans Bihs

This file is part of REEF3D.

REEF3D is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, see <http://www.gnu.org/licenses/>.
--------------------------------------------------------------------
Author: Hans Bihs
--------------------------------------------------------------------*/

#ifndef FNPF_WENO5_WD_H_
#define FNPF_WENO5_WD_H_

#include"fnpf_convection.h"
#include"increment.h"
#include"fnpf_sz_weights.h"
#include"fnpf_ddweno_f_nug.h"

using namespace std;

class fnpf_weno5_wd final : public fnpf_convection, public increment, public fnpf_ddweno_f_nug
{
public:
    fnpf_weno5_wd(lexer*);
    virtual ~fnpf_weno5_wd();

    double fx(lexer*, field&, double, double) override final;
    double fy(lexer*, field&, double, double) override final;
    double fz(lexer*, field&, double, double) override final;

    double sx(lexer*, slice&, double) override final;
    double sy(lexer*, slice&, double) override final;
    double sz(lexer*, double*) override final;

private:
    fnpf_sz_weights szw;
    double **ckz;
};

#endif
