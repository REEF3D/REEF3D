/*--------------------------------------------------------------------
REEF3D
Copyright 2018-2026 Tobias Martin

This file is part of REEF3D.

REEF3D is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, see <http://www.gnu.org/licenses/>.
--------------------------------------------------------------------
Authors: Tobias Martin, Hans Bihs
--------------------------------------------------------------------*/

#include"net_barDyn.h"
#include"lexer.h"
#include"fdm_nhf.h"
#include"ghostcell.h"	

void net_barDyn::update_velocity_nhflow(lexer *p, fdm_nhf *d, ghostcell *pgc)
{
    //- Store old velocities
    for (int i = 0; i < nK; i++)
    {
        coupledFieldn[i][0] = coupledField[i][0];
        coupledFieldn[i][1] = coupledField[i][1];
        coupledFieldn[i][2] = coupledField[i][2];
    }

    //- Get velocities at knots
    updateField_nhflow(p, d, pgc, 0);
    updateField_nhflow(p, d, pgc, 1);	
    updateField_nhflow(p, d, pgc, 2);
    
    //- Get density at knots
    updateField_nhflow(p, d, pgc, 3);  
}


void net_barDyn::updateField_nhflow(lexer *p, fdm_nhf *d, ghostcell *pgc, int cmp)
{
	int *recField, *count;

	p->Iarray(count,p->mpi_size);
	p->Iarray(recField, nK);
    
	// Get velocities on own processor
	for (int i = 0; i < nK; i++)
	{	
		if 
		(
			x_(i,0) >= xstart[p->mpirank] && x_(i,0) < xend[p->mpirank] &&
			x_(i,1) >= ystart[p->mpirank] && x_(i,1) < yend[p->mpirank] &&
			x_(i,2) >= zstart[p->mpirank] && x_(i,2) < zend[p->mpirank]
		)
		{
			if (cmp==0)
			{
				coupledField[i][cmp] = p->ccipol4V(d->U,d->WL,d->bed,x_(i,0),x_(i,1),x_(i,2));
			}
			else if (cmp==1)
			{
				coupledField[i][cmp] = p->ccipol4V(d->V,d->WL,d->bed,x_(i,0),x_(i,1),x_(i,2));
			}
			else if (cmp==2)
			{
				coupledField[i][cmp] =  p->ccipol4V(d->W,d->WL,d->bed,x_(i,0),x_(i,1),x_(i,2));
			}
			else if (cmp==3)
			{
				// water below the free surface, air above (no fluid loads on dry net parts)
				coupledField[i][cmp] = (x_(i,2) <= p->ccslipol4(d->WL,x_(i,0),x_(i,1)) + p->ccslipol4(d->bed,x_(i,0),x_(i,1))) ? p->W1 : p->W3;
			}
            
			recField[i] = -1;
			count[p->mpirank]++;
		}
		else
		{
			for (int j = 0; j < p->mpi_size; j++)
			{	
				if 
				(
					x_(i,0) >= xstart[j] && x_(i,0) < xend[j] &&
					x_(i,1) >= ystart[j] && x_(i,1) < yend[j] &&
					x_(i,2) >= zstart[j] && x_(i,2) < zend[j]
				)
				{
					recField[i] = j;
					count[j]++;
					break;
				}
				else
				{
					recField[i] = -2;
				}
			}			
		}
	}

	
	// Fill array for sending
	double *sendField;
	p->Darray(sendField, count[p->mpirank]);
	
	int counts = 0;
	for (int i = 0; i < nK; i++)
	{
		if (recField[i]==-1)
		{
			sendField[counts] = coupledField[i][cmp];
			counts++;
		}
	}


	// Prepare arrays for receiving
	double **recvField;

	recvField = new double*[p->mpi_size];

	for (int n = 0; n < p->mpi_size; ++n)
	{
		recvField[n] = new double[count[n]];
		
		for (int m = 0; m < count[n]; ++m)
		recvField[n][m] = 0.0;
	}

	
	// Send and receive
	vector<MPI_Request> sreq(p->mpi_size, MPI_REQUEST_NULL);
	vector<MPI_Request> rreq(p->mpi_size, MPI_REQUEST_NULL);
	MPI_Status status;
	
	for (int j = 0; j < p->mpi_size; j++)
	{
		if (j!=p->mpirank)
		{
			if (count[p->mpirank] > 0)
			{
			//	cout<<"Processor "<<p->mpirank<<" sends "<<count[p->mpirank]<<" elements to processor "<<j<<endl;
				
				MPI_Isend(sendField,count[p->mpirank],MPI_DOUBLE,j,1,pgc->mpi_comm,&sreq[j]);
			}
			
			if (count[j] > 0)
			{
			//	cout<<"Processor "<<p->mpirank<<" receives "<<count[j]<<" elements from processor "<<j<<endl;					
		
				MPI_Irecv(recvField[j],count[j],MPI_DOUBLE,j,1,pgc->mpi_comm,&rreq[j]);
			}
		}
	}

	// Wait until transmitted
	for (int j = 0; j < p->mpi_size; j++)
	{
		MPI_Wait(&sreq[j],&status);
		MPI_Wait(&rreq[j],&status);
	}
	
	
	// Fill velocity vector
	for (int j = 0; j < p->mpi_size; j++)
	{
		if (j!=p->mpirank)
		{
			count[j] = 0;
		}
	}
		
	for (int i = 0; i < nK; i++)
	{
		for (int j = 0; j < p->mpi_size; j++)
		{			
			if (recField[i]==j)
			{		
				coupledField[i][cmp] = recvField[j][count[j]];
				count[j]++;
			}
		}
	}
	
	for (int i = 0; i < nK; i++)
	{	 
		coupledField[i][cmp] += 1e-10;
	}	


	// Delete arrays
	if (count[p->mpirank] > 0)
	{
		p->del_Darray(sendField, count[p->mpirank]);
	}

    for(int i = 0; i < p->mpi_size; ++i)
	{
		if (count[i] > 0)
		{
			delete [ ] recvField[i];
		}
	}
	delete [ ] recvField;
	
	p->del_Iarray(count,p->mpi_size);
	p->del_Iarray(recField, nK);
}
