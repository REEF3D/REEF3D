/*--------------------------------------------------------------------
REEF3D
Copyright 2008-2026 Hans Bihs

This file is part of REEF3D.

REEF3D is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, see <http://www.gnu.org/licenses/>.
--------------------------------------------------------------------
Author: Hans Bihs
--------------------------------------------------------------------*/

#include"nhflow_concentration_IM1.h"
#include"lexer.h"
#include"fdm_nhf.h"
#include"ghostcell.h"
#include"nhflow_scalar_convection.h"
#include"nhflow_diffusion.h"
#include"ioflow.h"
#include"solver.h"
#include"sediment_fdm.h"

nhflow_concentration_IM1::nhflow_concentration_IM1(lexer* p, fdm_nhf *d, ghostcell *pgc) : nhflow_concentration_io(p,d)
{
	gcval_conc=60;
}

nhflow_concentration_IM1::~nhflow_concentration_IM1()
{
}

void nhflow_concentration_IM1::start(lexer *p, fdm_nhf *d, nhflow_scalar_convection *pconvec, nhflow_diffusion *pdiff, 
                                nhflow_turbulence *pturb, solver* psolv, ghostcell* pgc, ioflow* pflow)
{
    starttime=pgc->timer();
    clearrhs(p,d);
    pconvec->start(p,d,C,4,d->U,d->V,d->omegaF);
    pdiff->diff_scalar(p,d,pgc,psolv,C,1.0,1.0);
	concsource(p,d,C);
	timesource(p,d,C);
    bcconc_start(p,d,pgc,C);
    psolv->startV(p,pgc,C,d->rhsvec,d->M,4);
	pgc->start60V(p,C,gcval_conc);
}

void nhflow_concentration_IM1::timesource(lexer* p, fdm_nhf *d, double *CN)
{
    int count=0;
    int q;

    LOOP
    {
        d->M.p[count]+= 1.0/p->dt;

        d->rhsvec.V[count] += d->L[IJK] + C[IJK]/p->dt;

	++count;
    }
}

void nhflow_concentration_IM1::ctimesave(lexer *p, fdm_nhf *d)
{
}


void nhflow_concentration_IM1::concsource(lexer* p, fdm_nhf *d, double *CONC)
{    /*
    double zdist;
    
    count=0;
    LOOP
    {   
        if(k==0)
        {
        zdist = p->DZN[KP]*d->WL(i,j);
        d->rhsvec.V[count]  += (-s->ws)*(s->cb(i,j)-s->cbe(i,j))/(zdist);
        
        //d->rhsvec.V[count]  += s->ws*s->cbe(i,j)/(zdist);
        }

	++count;
    }*/
}

void nhflow_concentration_IM1::bcconc_start(lexer *p, fdm_nhf *d, ghostcell *pgc, double *CONC)
{
    double cval;
    
        int n=0;
        LOOP
        {
            if((p->flag4[Im1JK]<0 || p->DF[Im1JK]<0))
            {
            d->rhsvec.V[n] -= d->M.s[n]*CONC[IJK];
            d->M.s[n] = 0.0;
            }
            
            if((p->flag4[Ip1JK]<0 || p->DF[Ip1JK]<0))
            {
            d->rhsvec.V[n] -= d->M.n[n]*CONC[IJK];
            d->M.n[n] = 0.0;
            }
            
            if(p->j_dir==1)
            if((p->flag4[IJm1K]<0 || p->DF[IJm1K]<0))
            {
            d->rhsvec.V[n] -= d->M.e[n]*CONC[IJK];
            d->M.e[n] = 0.0;
            }
            
            if(p->j_dir==1)
            if((p->flag4[IJp1K]<0 || p->DF[IJp1K]<0))
            {
            d->rhsvec.V[n] -= d->M.w[n]*CONC[IJK];
            d->M.w[n] = 0.0;
            }
            
            if(p->flag4[IJKm1]<0 || p->DF[IJKm1]<0)
            {
            d->rhsvec.V[n] -= d->M.b[n]*CONC[IJK];
            d->M.b[n] = 0.0;
            }
            
            if(p->flag4[IJKp1]<0 || p->DF[IJKp1]<0)
            {
            d->rhsvec.V[n] -= d->M.t[n]*CONC[IJK];
            d->M.t[n] = 0.0;
            }

        ++n;
        }
        
        
    // turn off inside direct forcing body
        n=0;
        LOOP
        {
            if(p->DF[IJK]<0)
            {
            d->M.p[n] = 1.0;

            d->M.n[n] = 0.0;
            d->M.s[n] = 0.0;

            d->M.w[n] = 0.0;
            d->M.e[n] = 0.0;

            d->M.t[n] = 0.0;
            d->M.b[n] = 0.0;
            
            d->rhsvec.V[n] = 0.0;
            }
        ++n;
        }
}


void nhflow_concentration_IM1::clearrhs(lexer* p, fdm_nhf *d)
{
    int n=0;
    LOOP
    {    
    d->rhsvec.V[n]=0.0;
    d->L[IJK]=0.0;
	++n;
    }
}
