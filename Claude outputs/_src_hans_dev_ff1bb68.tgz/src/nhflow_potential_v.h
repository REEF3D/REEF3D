/*--------------------------------------------------------------------
REEF3D
Copyright 2008-2026 Hans Bihs

This file is part of REEF3D.

REEF3D is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, see <http://www.gnu.org/licenses/>.
--------------------------------------------------------------------
Author: Hans Bihs
--------------------------------------------------------------------*/

#ifndef NHFLOW_POTENTIAL_V_H_
#define NHFLOW_POTENTIAL_V_H_

#include"nhflow_potential.h"

using namespace std;

class nhflow_potential_v final : public nhflow_potential
{
public:
    nhflow_potential_v();
	virtual ~nhflow_potential_v();

	void start(lexer*, fdm_nhf*, solver*, ghostcell* pgc) override final;

};

#endif


