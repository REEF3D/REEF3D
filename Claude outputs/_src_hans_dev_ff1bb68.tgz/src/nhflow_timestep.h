/*--------------------------------------------------------------------
REEF3D
Copyright 2008-2026 Hans Bihs

This file is part of REEF3D.

REEF3D is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, see <http://www.gnu.org/licenses/>.
--------------------------------------------------------------------
Author: Hans Bihs
--------------------------------------------------------------------*/

#ifndef NHFLOW_TIMESTEP_H_
#define NHFLOW_TIMESTEP_H_

#include"timestep.h"
#include"increment.h"

class fdm_nhf;
class lexer;
class ghostcell;

using namespace std;

// mesh refinement (nhflow_amr): the refined patches take part in the time step
class nhflow_timestep_hook
{
public:
    // maximum over the patch cells on this rank: 0 WL, 1 |U|, 2 |V|, 3 |W|, 4 |omega|
    virtual double dt_local_max(int)=0;
    // smallest horizontal cell size (and dz*WL) of the patch cells on this rank (1: wet cells only)
    virtual void dt_cell_size(int, double&, double&)=0;
};

class nhflow_timestep : public increment
{
public:
	nhflow_timestep(lexer*);
	virtual ~nhflow_timestep();
	void start(lexer*,fdm_nhf*,ghostcell*);
	void ini(lexer*,fdm_nhf*,ghostcell*);
    
    nhflow_timestep_hook *phook = nullptr;


private:
	double wallu,wallv,wallw;
	double cu,cv,cw,co;
	const double epsi;
	double isor,jsor,ksor;
	double irsm,jrsm,krsm;
    const double maxtimestep, c0_orig;
    double dx,dz;

};

#endif
