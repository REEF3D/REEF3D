/*--------------------------------------------------------------------
REEF3D
Copyright 2008-2026 Hans Bihs

This file is part of REEF3D.

REEF3D is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, see <http://www.gnu.org/licenses/>.
--------------------------------------------------------------------
Author: Hans Bihs
--------------------------------------------------------------------*/

#ifndef SFLOW_HEADER_H_
#define SFLOW_HEADER_H_

#include"lexer.h"
#include"fdm2D.h"
#include"fdm.h"
#include"ghostcell.h"
#include"iowave.h"
#include"ioflow_f.h"
#include"ioflow_void.h"
#ifdef REEF3D_USE_HYPRE
#include"hypre_struct2D.h"
#endif
#include"reefmg2D.h"
#include"sflow_bicgstab.h"
#include"sflow_forcing.h"

#include"sflow_etimestep.h"
#include"sflow_fixtimestep.h"
#include"sflow_fou.h"
#include"sflow_weno_flux.h"
#include"sflow_HLL.h"
#include"sflow_signal_speed.h"
#include"sflow_reconstruct_hires.h"
#include"sflow_reconstruct_weno.h"
#include"sflow_eta.h"
#include"sflow_momentum_RK3.h"
#include"sflow_amr.h"
#include"sflow_momentum_RK2.h"


#include"sflow_turb_void.h"
#include"sflow_turb_prandtl.h"
#include"sflow_turb_parabolic.h"
#include"sflow_turb_kw_IM1.h"
#include"sflow_turb_kw_IM1_v1.h"
#include"sflow_turb_ke_IM1.h"

#include"sflow_hydrostatic.h"
#include"sflow_vtp_fsf.h"
#include"sflow_vtp_bed.h"
#include"sflow_diffusion_void.h"
#include"sflow_ediff.h"
#include"sflow_idiff.h"
#include"sflow_pjm_lin.h"
#include"sflow_pjm_quad.h"
#include"sflow_filter.h"

#include"sediment_f.h"
#include"sediment_void.h"

#include"sflow_potential_f.h"
#include"sflow_potential_v.h"

#include"patchBC_void.h"

#include"6DOF_void.h"
#include"6DOF_sflow.h"
#include"vrans_header.h"
#include"turbulence.h"

#endif
