# 05 KCS Fr 0.26, fine grid (dx = 0.07 m): case for a workstation run

The fine-grid run of validation 05 (dx = dy = 0.07 m, 372 x 100 cells, 24 sigma layers) needs
about 3.5 h on 2 cores. The cloud workspace is recycled when the session is idle, which has
stopped this run three times so far. This folder is the complete case so that it can run on a
workstation. Copy `fr026_fine/` to `validation/05_kcs_resistance/fr026_fine/`.

```
cd fr026_fine
# optional: more MPI ranks, e.g. M 10 8 in control.txt and ctrl.txt
DiveMESH; mpirun -np 2 REEF3D
mkdir results; cp REEF3D_NHFLOW_6DOF/*.dat results/
cd ..; python3 plot05.py . fr026_fine           # averages; compare with fr026 (dx = 0.1 m)
```

Everything else is as in fr026: the same STL, ship.dat, inflow, beach and duration (25 s).
Code: hans_dev with patches 0007, 0008 (0009 for the `current` key).
