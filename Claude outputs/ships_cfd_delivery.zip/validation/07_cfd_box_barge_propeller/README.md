# 07 Box barge with a body-force propeller in REEF3D::CFD (patches 0010, 0011)

First use of the ship module in REEF3D::CFD: the box barge of validation 02 accelerates from rest
with a propeller at fixed rps, in a two-phase level-set tank. Two variants, as in 02:

| run | propeller |
|---|---|
| `cfd_nodisk/` | thrust and torque act on the hull only (`propeller_source 0`, thrust deduction 0) |
| `cfd_disk_aft/` | Hough-Ordway actuator disk in the fluid, 0.4 m (3.3 D) behind the transom, thickness 0.1 m (default in CFD now) |

`nhflow/` holds the same two runs of validation 02 again, rerun with patch 0010 (swirl without
net force, vertical source). This is a verification of the coupling and a comparison of the two
solvers, not a validation against experiments.

## Set-up

| | |
|---|---|
| Solver | REEF3D::CFD (A 10 6), two-phase level set (F 30 3, F 40 3), SSP-RK3 (N 40 3), 2 MPI ranks |
| Tank | 14 x 2 m, water depth 0.5 m, 0.2 m air above, walls all round, calm water |
| Grid | dx = 0.05 m, 280 x 40 x 14 cells |
| Hull | box X 110: L = 1.0 m, B = 0.3 m, height 0.3 m, density 500 kg/m^3, draft 0.15 m; surge, heave, pitch free |
| Hull loads | CFD pressure and viscous force on the hull + ITTC-1957 friction (1+k = 1.1, `friction 1`). dx = 0.05 m does not resolve the boundary layer: the CFD viscous force is only 0.003 N, so the correlation line is switched on as in NHFLOW |
| Propeller | D = 0.12 m, hub 0.2 D, centre 0.07 m below the CoG (0.07 m below the still water level), n = 6 1/s, KT = 0.33 - 0.25 J - 0.08 J^2, KQ = 0.045 - 0.03 J - 0.01 J^2, wake fraction 0.2 |
| Duration | 20 s, about 1500 steps, 25 to 35 min per run on 2 cores |

Each run folder holds control.txt (DIVEMesh), ctrl.txt, ship.dat, and in `results/` the 6DOF
logs and REEF3D_ship_0.dat.

## How the disk is coupled to CFD

- **Staggered grids.** The source goes on the velocity points of each component (u, v, w). Each
  component is normalised on its own grid, so the force on the fluid is exactly -T along the
  axis and the torque exactly Q about it.
- **Water part outside the hull.** A velocity point gets the source only in proportion to its
  water fraction outside the bodies: (1 - fbh) times the water fraction from the face density.
  Here 17 % of the disk weight lies in the smeared free surface (the tip is 1 cm below the
  still water level), and the coupling prints a warning. The remaining 83 % carry the full T and Q.
- **Acceleration.** The force density is divided by the face density and added to the forcing
  terms fx, fy, fz of the stage. It is applied after all bodies have set their Heaviside, so
  every CFD momentum scheme that calls the 6DOF forcing gets it.
- **Velocity sampling.** The load models can now sample the CFD velocity (propeller inflow
  `sample`, rudder inflow).

**Swirl (patch 0010, both solvers).** With D = 2.4 cells the tangential unit vectors of the
cells in the disk do not cancel. The old distribution Q wt et / sum(wt r V) gave a net side or
vertical force of 3 to 10 % of T, depending on where the disk sits relative to the grid. The
unit test `Regression/unit/ship_test.cpp` shows 10 % on its test grid. The swirl now has no net
force on each grid. The torque about the axis, including the small torque of the thrust part
on staggered grids, is exactly Q. The unit test checks this to 1e-12 on a staggered grid and on
cell centres, with an inclined shaft and partial fluid fractions.

**NHFLOW (patch 0010).** The W momentum equation never called the 6DOF source, so the
vertical part of the swirl was lost. It is now added.

## Results

![speed, thrust, hull force](cfd_nhflow_propeller.png)

Averages over the last 5 s; u at 20 s:

| run | u(20 s) | J | T [N] | Q [Nm] | solver hull force -F_x [N] | of which viscous (CFD) | ITTC friction -X_F [N] | thrust deduction t |
|---|---|---|---|---|---|---|---|---|
| CFD, thrust on the hull | 0.329 m/s | 0.356 | 1.72 | 0.0296 | 1.31 | 0.003 | 0.24 | 0 (input) |
| CFD, actuator disk | 0.313 m/s | 0.339 | 1.76 | 0.0302 | 1.39 | 0.003 | 0.22 | 0.11 |
| NHFLOW, thrust on the hull | 0.250 m/s | 0.275 | 1.90 | 0.0322 | 1.81 | - | 0.15 | 0 (input) |
| NHFLOW, actuator disk | 0.241 m/s | 0.265 | 1.92 | 0.0325 | 1.82 | - | 0.14 | 0.08 |

As in 02, the thrust deduction is the extra hull force relative to the hull without the jet,
scaled with u^2: t = (-F_x - F_nodisk (u/u_nodisk)^2)/T. The runs are still accelerating
slowly at 20 s (CFD faster than NHFLOW), so t holds to about +-0.03.

- **Thrust deduction, same in both solvers within the accuracy.** With the disk 3.3 D behind
  the transom, the jet adds a small suction on the hull: t = 0.11 in CFD, 0.08 in NHFLOW. The
  speed drops by 4.9 % in CFD and 3.6 % in NHFLOW.
- **Resistance, different in the two solvers.** CFD gives a much lower pressure resistance of
  the box than NHFLOW: 1.31 N at 0.33 m/s, vs 1.81 N at 0.25 m/s, which scales to about
  3.1 N at 0.33 m/s. So the CFD barge is 30 % faster. Possible reasons:
  - the flow at the sharp transom and bow edges of the box (separation, dead water);
  - the 10 sigma layers of NHFLOW over 0.5 m depth;
  - the 2 to 3 cell forcing band of both solvers.
  This is a property of the hull flow, not of the propeller coupling. A grid study of the box
  in both solvers would separate it (see 05 for the KCS).
- **Induced flow in CFD** (centre plane, ship frame of reference):

![induced flow](cfd_induced_flow.png)

  Without the disk, the box drags a forward-moving wake of up to +0.4 m/s behind the transom. The
  disk pushes a backward jet of about -0.1 m/s (inertial frame) through this wake. It reaches
  3 m aft at the depth of the disk, and the wake ahead of the disk is shorter. This is the same
  picture as NHFLOW in 02.
- **NHFLOW with patch 0010** gives the same speed as before: 0.241 m/s with the disk (02:
  0.241) and t = 0.08 (02: about 0.06). The swirl correction and the vertical source change
  the integral result by less than the accuracy here. They matter for sway and yaw, e.g. in
  manoeuvring: in the zig-zag regression case the sway velocity changes by 50 % after 60 steps.
- **Side force and yaw moment.** The CFD hull force has a small side force and yaw moment (up
  to 0.03 N and 0.03-0.04 Nm) in both CFD runs, with and without the disk. It comes from the
  CFD force integration on the symmetric box, not from the source. Sway and yaw are fixed here.

## Run

```
cd cfd_disk_aft; DiveMESH; mpirun -np 2 REEF3D      # control.txt, ctrl.txt, ship.dat (likewise cfd_nodisk, nhflow/*)
mkdir results; cp REEF3D_CFD_6DOF/*.dat results/    # NHFLOW: REEF3D_NHFLOW_6DOF
python3 plot07.py .                                 # figure and table
python3 induced07.py .                              # needs REEF3D_CFD_VTU of the CFD runs (P 30 2.0), not stored here
```

Code: hans_dev e0e5042 + patches 0007, 0008, 0010, 0011.
