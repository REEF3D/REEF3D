# Architect: Hans Bihs
# Validation 07: induced flow of the actuator disk in REEF3D::CFD, centre plane y = 1 m, at the last
# VTU output (P 30 2.0) of cfd_disk_aft and cfd_nodisk; needs the REEF3D_CFD_VTU folders of the runs
import re, glob, os, sys, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

base = sys.argv[1] if len(sys.argv) > 1 else '.'

def read_piece(fn):
    buf = open(fn, 'rb').read()
    i = buf.index(b'<AppendedData encoding="raw">')
    head = buf[:i].decode()
    start = buf.index(b'_', i) + 1
    out = {}
    for m in re.finditer(r'<DataArray type="(\w+)"(?: Name="(\w+)")?(?: NumberOfComponents="(\d+)")? format="appended" offset="(\d+)"', head):
        typ, name, nc, off = m.group(1), m.group(2) or 'points', int(m.group(3) or 1), int(m.group(4))
        if typ != 'Float32':
            continue
        n = np.frombuffer(buf, np.int32, 1, start + off)[0]
        a = np.frombuffer(buf, np.float32, n//4, start + off + 4)
        out[name] = a.reshape(-1, nc) if nc > 1 else a
    return out

def read(stem):
    ps = [read_piece(f) for f in sorted(glob.glob(stem + '-*.vtu'))]
    return {k: np.concatenate([p[k] for p in ps]) for k in ('points', 'velocity', 'phi')}

runs = [('cfd_nodisk', 'thrust on the hull only'), ('cfd_disk_aft', 'actuator disk 0.4 m behind the transom')]
fig, axs = plt.subplots(2, 1, figsize=(11, 5.2))
for q, (d, lab) in enumerate(runs):
    pv = sorted(glob.glob(os.path.join(base, d, 'REEF3D_CFD_VTU', '*.pvtu')))
    v = read(pv[-1][:-5])
    P, U, phi = v['points'], v['velocity'], v['phi']
    m = (np.abs(P[:, 1] - 1.0) < 1e-3) & (phi > 0.0)
    pos = np.genfromtxt(os.path.join(base, d, 'results', 'REEF3D_6DOF_position_0.dat'), skip_header=1)
    tv = float(re.search(r'(\d+)\.pvtu', pv[-1]).group(1))*2.0
    xc = np.interp(tv, pos[:, 0], pos[:, 1])
    a = axs[q]
    t = a.tricontourf(P[m, 0] - xc, P[m, 2], U[m, 0], levels=np.linspace(-0.4, 0.4, 33), cmap='RdBu_r', extend='both')
    a.fill_between([-0.5, 0.5], [0.35, 0.35], [0.5, 0.5], color='0.6')
    if 'disk' in d and 'nodisk' not in d:
        a.add_patch(plt.Rectangle((-0.95, 0.43 - 0.06), 0.1, 0.12, fill=False, ec='k', lw=1.0))
    a.set(xlim=(-4.0, 1.5), ylim=(0, 0.52), ylabel='z [m]', title='CFD u [m/s] (inertial) in y = 1 m, t = %.0f s: %s' % (tv, lab))
    fig.colorbar(t, ax=a, pad=0.01)
axs[-1].set_xlabel('x - x_CoG [m]')
fig.tight_layout()
fig.savefig(os.path.join(base, 'cfd_induced_flow.png'), dpi=110)
