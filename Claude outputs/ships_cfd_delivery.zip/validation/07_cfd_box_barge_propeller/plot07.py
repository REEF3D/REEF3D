# Architect: Hans Bihs
# Validation 07: box barge with a body-force propeller in REEF3D::CFD (patch 0011) compared with
# REEF3D::NHFLOW (validation 02, rerun with patch 0010): actuator disk 0.4 m behind the transom
# and thrust on the hull only
import numpy as np, matplotlib, os, sys
matplotlib.use('Agg')
import matplotlib.pyplot as plt

base = sys.argv[1] if len(sys.argv) > 1 else '.'
runs = [('cfd_nodisk', 'CFD, thrust on the hull', '#2a78d6', '--'),
        ('cfd_disk_aft', 'CFD, actuator disk', '#2a78d6', '-'),
        ('nhflow/nodisk', 'NHFLOW, thrust on the hull', '#eb6834', '--'),
        ('nhflow/disk_aft', 'NHFLOW, actuator disk', '#eb6834', '-')]

def load(d):
    r = os.path.join(base, d, 'results')
    s = np.genfromtxt(os.path.join(r, 'REEF3D_ship_0.dat'), skip_header=1)
    f = np.genfromtxt(os.path.join(r, 'REEF3D_6DOF_forces_0.dat'), skip_header=1)
    return s, f

R = {}
for d, lab, c, ls in runs:
    if os.path.exists(os.path.join(base, d, 'results', 'REEF3D_ship_0.dat')):
        R[d] = load(d)

def avg(t, y, t0, t1):
    m = (t >= t0) & (t <= t1)
    return y[m].mean()

fig, ax = plt.subplots(2, 2, figsize=(12, 8))
rows = {}
for d, lab, c, ls in runs:
    if d not in R:
        continue
    s, f = R[d]
    ax[0, 0].plot(s[:, 0], s[:, 1], color=c, ls=ls, label=lab)
    ax[0, 1].plot(s[:, 0], s[:, 17], color=c, ls=ls, label=lab)
    n = 51
    fx = np.convolve(f[:, 1], np.ones(n)/n, mode='same')
    ax[1, 0].plot(f[n:-n, 0], -fx[n:-n], color=c, ls=ls, label=lab)
    ax[1, 1].plot(s[:, 14], s[:, 15], color=c, ls=ls, label=lab)
    te = s[-1, 0]
    rows[d] = dict(lab=lab, te=te, u=s[-1, 1], J=avg(s[:, 0], s[:, 14], te - 5, te), T=avg(s[:, 0], s[:, 17], te - 5, te),
                   Q=avg(s[:, 0], s[:, 18], te - 5, te), F=-avg(f[:, 0], f[:, 1], te - 5, te),
                   Fv=-avg(f[:, 0], f[:, 10], te - 5, te), XF=-avg(s[:, 0], s[:, 7], te - 5, te),
                   ua=avg(s[:, 0], s[:, 1], te - 5, te))
ax[0, 0].set(xlabel='t [s]', ylabel='u [m/s]', title='surge speed')
ax[0, 0].legend(fontsize=8, frameon=False)
ax[0, 1].set(xlabel='t [s]', ylabel='T [N]', title='propeller thrust')
ax[1, 0].set(xlabel='t [s]', ylabel='-F_x [N]', title='hull force of the solver (moving average)')
ax[1, 0].set_ylim(0, 3)
ax[1, 1].set(xlabel='J', ylabel='KT', title='operating point on the KT curve')
J = np.linspace(0, 0.4, 50)
ax[1, 1].plot(J, 0.33 - 0.25*J - 0.08*J*J, 'k:', lw=0.8)
for a in ax.flat:
    a.grid(alpha=0.3)
fig.tight_layout()
fig.savefig(os.path.join(base, 'cfd_nhflow_propeller.png'), dpi=110)

print('| run | u(end) | J | T [N] | Q [Nm] | solver hull force -F_x [N] | of which viscous (CFD) | ITTC friction -X_F [N] | thrust deduction t |')
print('|---|---|---|---|---|---|---|---|---|')
for solver in ('cfd', 'nhflow'):
    nd = rows.get('cfd_nodisk' if solver == 'cfd' else 'nhflow/nodisk')
    for d in (('cfd_nodisk', 'cfd_disk_aft') if solver == 'cfd' else ('nhflow/nodisk', 'nhflow/disk_aft')):
        if d not in rows:
            continue
        r = rows[d]
        t = '0 (input)'
        if 'disk' in d and 'nodisk' not in d and nd is not None:
            # extra hull force relative to the hull without the jet at the same speed (u^2 scaling)
            t = '%.2f' % ((r['F'] - nd['F']*(r['ua']/nd['ua'])**2)/r['T'])
        fv = '%.3f' % r['Fv'] if solver == 'cfd' else '-'
        print('| %s | %.3f m/s | %.3f | %.2f | %.4f | %.2f | %s | %.2f | %s |' % (r['lab'], r['u'], r['J'], r['T'], r['Q'], r['F'], fv, r['XF'], t))
