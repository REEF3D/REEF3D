/*--------------------------------------------------------------------
REEF3D
Copyright 2008-2018 Hans Bihs

This file is part of REEF3D.

REEF3D is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, see <http://www.gnu.org/licenses/>.
--------------------------------------------------------------------
--------------------------------------------------------------------*/

#include"wave_lib_parameters.h"
#include"lexer.h"
#include"fdm.h"
#include"ghostcell.h"

wave_lib_parameters::wave_lib_parameters(lexer *p, ghostcell *pgc) : pshift(p->B120*(PI/180.0))
{ 
    
    p->phiin=p->phimean;
	
    
	wtype=p->B92;
    
    if(p->B110==0)
	wd=p->phimean;
	
	if(p->B110==1)
	wd=p->B110_d;
    
    p->wd=wd;
	
// Wave Length given
    if(p->B91==1 && p->B92<30)
    {

     // define wave parameters
    wa = p->B91_1;
    wH = 2.0*p->B91_1;
    wL = p->B91_2;

    wk= (2.0*PI)/(wL>1.0e-20?wL:1.0e20);

    // define frequency
    if(wtype==1)
    ww= (2.0*PI*sqrt(9.81*wd))/(wL);

    if(wtype==2)
    ww= sqrt(fabs(9.81*wk*tanh(wk*(wd))));

    if(wtype==3)
    ww= sqrt(9.81*wk);

    if(wtype==4 || wtype>5)
    ww= sqrt(fabs(9.81*wk*tanh(wk*(wd))));
	
	wf = ww/(2.0*PI);
    wT = 1.0/wf;
	
	if(wtype==5)
	{
	eps = 0.5*wk*wH;
	S = 1.0/cosh(2*wk*wd);
	C = 1.0 - S;
	
	c0 = sqrt(tanh(wk*wd));

    c2 = (c0*(2.0 + 7.0*S*S)/(4.0*C*C));

    c4 = (c0*(4.0 + 32.0*S -116.0*S*S - 400.0*S*S*S - 71.0*pow(S,4.0) + 146.0*pow(S,5.0)))/(32.0*pow(C,5.0));
	
	
	wT= (2.0*PI)/(sqrt(9.81*wk)*(c0 + eps*eps*c2 + eps*eps*eps*eps*c4));
	wf = 1.0/wT;
	ww = 2.0*PI*wf;
    
	
	wC = ww/wk;
	ubar = (c0 + eps*eps*c2 + eps*eps*eps*eps*c4)/sqrt(wk/9.81);
	}
	 
    }


// Wave Period given
    if(p->B93==1 &&  p->B92<30)
    {		
		// define wave parameters
		wa = p->B93_1;
		wH = 2.0*p->B93_1;
		wT = p->B93_2;
		
		// define wave length
		if(wtype==1)
		wL= wT*sqrt(9.81*wd);

		if(wtype==3)
		wL= (9.81/(2.0*PI))*wT*wT;
		
		
		if(wtype==2 || wtype==4 || wtype>5)
		{
		wL0 = (9.81/(2.0*PI))*wT*wT;	
		k0 = (2.0*PI)/wL0;
		S0 = sqrt(k0*wd) * (1.0 + (k0*wd)/6.0 + (k0*k0*wd*wd)/30.0); 
		
		wL = wL0*tanh(S0);
        
        for(int qn=0; qn<500; ++qn)
        wL = wL0*tanh(2.0*PI*wd/wL);
		}
        
        
        if(wtype==5)
		{
		wL0 = (9.81/(2.0*PI))*wT*wT;	
		k0 = (2.0*PI)/wL0;
		S0 = sqrt(k0*wd) * (1.0 + (k0*wd)/6.0 + (k0*k0*wd*wd)/30.0); 
		
		wL = wL0*tanh(S0);
        
        for(int qn=0; qn<500; ++qn)
        wL = wL0*tanh(2.0*PI*wd/wL);
        
        diff=10.0;
        int qn=0;
            do
            {
            wk_temp = (2.0*PI)/(wL>1.0e-20?wL:1.0e20); // wk: wavenumber k
            
            eps = 0.5*wk_temp*wH;
            S = 1.0/cosh(2*wk_temp*wd);
            C = 1.0 - S;
            
            c0 = sqrt(tanh(wk_temp*wd));
            c2 = (c0*(2.0 + 7.0*S*S)/(4.0*C*C));
            c4 = (c0*(4.0 + 32.0*S -116.0*S*S - 400.0*S*S*S - 71.0*pow(S,4.0) + 146.0*pow(S,5.0)))/(32.0*pow(C,5.0));
        
            wT_temp = (2.0*PI)/(sqrt(9.81*wk_temp)*(c0 + eps*eps*c2 + eps*eps*eps*eps*c4));
            
            diff=wT_temp-wT;
            
            //cout<<"wT_temp: "<<wT_temp<<" wT: "<<wT<<" wL: "<<wL<<" diff: "<<diff<<" qn: "<<qn<<endl;
            
            if(diff>0.0001)
            wL-=0.0005;
                
            if(diff<-0.0001)
            wL+=0.0005;
                ++qn;
            }while(fabs(diff)>0.0001 && qn<9000);
            
		}
        

		wf = 1.0/wT;
		ww = wf*2.0*PI;
 
		wk= (2.0*PI)/(wL>1.0e-20?wL:1.0e20);	
        
        if(wtype==5)
        {
        wf = 1.0/wT;
        ww = 2.0*PI*wf;
        
        wC = ww/wk;
        ubar = (c0 + eps*eps*c2 + eps*eps*eps*eps*c4)/sqrt(wk/9.81);
        }
	}
	
	

    p->wT = wT;
    p->wH = wH;
    p->wA = wa;
    p->wL = wL;
    p->wd = wd;
    p->wk = wk;
    p->ww = ww;
    
    
    if(p->B92>30)
	{
	p->wHs = p->B93_1;
    p->wAs = 0.5*p->B93_1;
    p->wA = p->wAs;
	p->wTp = p->B93_2;
	wT = p->B93_2;
	p->wwp = 2.0*PI/p->wTp;
	}
	
}

wave_lib_parameters::~wave_lib_parameters()
{
}








