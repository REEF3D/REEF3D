/*--------------------------------------------------------------------
REEF3D
Copyright 2008-2019 Hans Bihs

This file is part of REEF3D.

REEF3D is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, see <http://www.gnu.org/licenses/>.
--------------------------------------------------------------------
--------------------------------------------------------------------*/

#include"nodefill.h"
#include"lexer.h"
#include"fdm.h"
#include"ghostcell.h"
#include"norm_vec.h"


nodefill::nodefill(lexer *p) 
{
}

nodefill::~nodefill()
{
}

void nodefill::nodefill4(lexer *p, fdm *a, ghostcell *pgc, field &f, field &eta) 
{
    pip=5;
	TPLOOP
	eta(i,j,k)=0.0;

	double val,factor,denom;
	int q;

	FLUIDLOOP
	{
		val = f(i,j,k);
		
		eta(i,j,k) += 0.125*val;
		eta(i,j-1,k) += 0.125*val;
		eta(i,j,k-1) += 0.125*val;
		eta(i,j-1,k-1) += 0.125*val;
		eta(i-1,j,k) += 0.125*val;
		eta(i-1,j-1,k) += 0.125*val;
		eta(i-1,j,k-1) += 0.125*val;
		eta(i-1,j-1,k-1) += 0.125*val;
	}

	
	GC4LOOP
	{
		i=p->gcb4[n][0];
		j=p->gcb4[n][1];
		k=p->gcb4[n][2];
		
		if(p->gcb4[n][3]==1)
		{
		val = f(i-1,j,k);
		
		eta(i-1,j,k) += 0.125*val * (1.0/double(p->gcside4[n]));
		eta(i-1,j-1,k) += 0.125*val * (1.0/double(p->gcside4[n]));
		eta(i-1,j,k-1) += 0.125*val * (1.0/double(p->gcside4[n]));
		eta(i-1,j-1,k-1) += 0.125*val * (1.0/double(p->gcside4[n]));
		}
			
		if(p->gcb4[n][3]==4)
		{
		val = f(i+1,j,k);
		
		eta(i,j,k) += 0.125*val * (1.0/double(p->gcside4[n]));
		eta(i,j-1,k) += 0.125*val * (1.0/double(p->gcside4[n]));
		eta(i,j,k-1) += 0.125*val * (1.0/double(p->gcside4[n]));
		eta(i,j-1,k-1) += 0.125*val * (1.0/double(p->gcside4[n]));
		}
		
		
		if(p->gcb4[n][3]==3)
		{
		val = f(i,j-1,k);
		
		eta(i,j-1,k) += 0.125*val * (1.0/double(p->gcside4[n]));
		eta(i-1,j-1,k) += 0.125*val * (1.0/double(p->gcside4[n]));
		eta(i,j-1,k-1) += 0.125*val * (1.0/double(p->gcside4[n]));
		eta(i-1,j-1,k-1) += 0.125*val * (1.0/double(p->gcside4[n]));
		}
			
		if(p->gcb4[n][3]==2)
		{
		val = f(i,j+1,k);
		
		eta(i,j,k) += 0.125*val * (1.0/double(p->gcside4[n]));
		eta(i-1,j,k) += 0.125*val * (1.0/double(p->gcside4[n]));
		eta(i,j,k-1) += 0.125*val * (1.0/double(p->gcside4[n]));
		eta(i-1,j,k-1) += 0.125*val * (1.0/double(p->gcside4[n]));
		}
		
		
		if(p->gcb4[n][3]==5)
		{
		val = f(i,j,k-1);
		
		eta(i,j,k-1) += 0.125*val * (1.0/double(p->gcside4[n]));
		eta(i-1,j,k-1) += 0.125*val * (1.0/double(p->gcside4[n]));
		eta(i,j-1,k-1) += 0.125*val * (1.0/double(p->gcside4[n]));
		eta(i-1,j-1,k-1) += 0.125*val * (1.0/double(p->gcside4[n]));
		}
			
		if(p->gcb4[n][3]==6)
		{
		val = f(i,j,k+1);
		
		eta(i,j,k) += 0.125*val * (1.0/double(p->gcside4[n]));
		eta(i-1,j,k) += 0.125*val * (1.0/double(p->gcside4[n]));
		eta(i,j-1,k) += 0.125*val * (1.0/double(p->gcside4[n]));
		eta(i-1,j-1,k) += 0.125*val * (1.0/double(p->gcside4[n]));
		}
	}
	
	// Para
	for(n=0;n<p->gcpara1_count;++n)
    {
    i=p->gcpara1[n][0];
    j=p->gcpara1[n][1];
    k=p->gcpara1[n][2];
	
		val = f(i-1,j,k);
		
		eta(i-1,j,k) += 0.125*val;
		eta(i-1,j-1,k) += 0.125*val;
		eta(i-1,j,k-1) += 0.125*val;
		eta(i-1,j-1,k-1) += 0.125*val;
    }
	
	for(n=0;n<p->gcpara4_count;++n)
    {
    i=p->gcpara4[n][0];
    j=p->gcpara4[n][1];
    k=p->gcpara4[n][2];
	
		val = f(i+1,j,k);
		
		eta(i,j,k) += 0.125*val;
		eta(i,j-1,k) += 0.125*val;
		eta(i,j,k-1) += 0.125*val;
		eta(i,j-1,k-1) += 0.125*val;
    }
	
	for(n=0;n<p->gcpara3_count;++n)
    {
    i=p->gcpara3[n][0];
    j=p->gcpara3[n][1];
    k=p->gcpara3[n][2];
	
		val = f(i,j-1,k);
		
		eta(i,j-1,k) += 0.125*val;
		eta(i-1,j-1,k) += 0.125*val;
		eta(i,j-1,k-1) += 0.125*val;
		eta(i-1,j-1,k-1) += 0.125*val;
    }
	
	for(n=0;n<p->gcpara2_count;++n)
    {
    i=p->gcpara2[n][0];
    j=p->gcpara2[n][1];
    k=p->gcpara2[n][2];
	
		val = f(i,j+1,k);
		
		eta(i,j,k) += 0.125*val;
		eta(i-1,j,k) += 0.125*val;
		eta(i,j,k-1) += 0.125*val;
		eta(i-1,j,k-1) += 0.125*val;
    }
	
	for(n=0;n<p->gcpara5_count;++n)
    {
    i=p->gcpara5[n][0];
    j=p->gcpara5[n][1];
    k=p->gcpara5[n][2];
	
		val = f(i,j,k-1);
		
		eta(i,j,k-1) += 0.125*val;
		eta(i-1,j,k-1) += 0.125*val;
		eta(i,j-1,k-1) += 0.125*val;
		eta(i-1,j-1,k-1) += 0.125*val;
    }
	
	for(n=0;n<p->gcpara6_count;++n)
    {
    i=p->gcpara6[n][0];
    j=p->gcpara6[n][1];
    k=p->gcpara6[n][2];
	
		val = f(i,j,k+1);
		
		eta(i,j,k) += 0.125*val;
		eta(i-1,j,k) += 0.125*val;
		eta(i,j-1,k) += 0.125*val;
		eta(i-1,j-1,k) += 0.125*val;
    }
	
	// Para
	for(n=0;n<p->gcparavoid1_count;++n)
    {
    i=p->gcparavoid1[n][0];
    j=p->gcparavoid1[n][1];
    k=p->gcparavoid1[n][2];
	
		val = f(i-1,j,k);
		
		eta(i-1,j,k) += 0.125*val;
		eta(i-1,j-1,k) += 0.125*val;
		eta(i-1,j,k-1) += 0.125*val;
		eta(i-1,j-1,k-1) += 0.125*val;
    }
	
	for(n=0;n<p->gcparavoid4_count;++n)
    {
    i=p->gcparavoid4[n][0];
    j=p->gcparavoid4[n][1];
    k=p->gcparavoid4[n][2];
	
		val = f(i+1,j,k);
		
		eta(i,j,k) += 0.125*val;
		eta(i,j-1,k) += 0.125*val;
		eta(i,j,k-1) += 0.125*val;
		eta(i,j-1,k-1) += 0.125*val;
    }
	
	for(n=0;n<p->gcparavoid3_count;++n)
    {
    i=p->gcparavoid3[n][0];
    j=p->gcparavoid3[n][1];
    k=p->gcparavoid3[n][2];
	
		val = f(i,j-1,k);
		
		eta(i,j-1,k) += 0.125*val;
		eta(i-1,j-1,k) += 0.125*val;
		eta(i,j-1,k-1) += 0.125*val;
		eta(i-1,j-1,k-1) += 0.125*val;
    }
	
	for(n=0;n<p->gcparavoid2_count;++n)
    {
    i=p->gcparavoid2[n][0];
    j=p->gcparavoid2[n][1];
    k=p->gcparavoid2[n][2];
	
		val = f(i,j+1,k);
		
		eta(i,j,k) += 0.125*val;
		eta(i-1,j,k) += 0.125*val;
		eta(i,j,k-1) += 0.125*val;
		eta(i-1,j,k-1) += 0.125*val;
    }
	
	for(n=0;n<p->gcparavoid5_count;++n)
    {
    i=p->gcparavoid5[n][0];
    j=p->gcparavoid5[n][1];
    k=p->gcparavoid5[n][2];
	
		val = f(i,j,k-1);
		
		eta(i,j,k-1) += 0.125*val;
		eta(i-1,j,k-1) += 0.125*val;
		eta(i,j-1,k-1) += 0.125*val;
		eta(i-1,j-1,k-1) += 0.125*val;
    }
	
	for(n=0;n<p->gcparavoid6_count;++n)
    {
    i=p->gcparavoid6[n][0];
    j=p->gcparavoid6[n][1];
    k=p->gcparavoid6[n][2];
	
		val = f(i,j,k+1);
		
		eta(i,j,k) += 0.125*val;
		eta(i-1,j,k) += 0.125*val;
		eta(i,j-1,k) += 0.125*val;
		eta(i-1,j-1,k) += 0.125*val;
    }
	
// Paraco
	int sidesum=0;
	int aa,bb,cc;
	
	// 1
	for(n=0;n<p->gcparaco1_count;++n)
    {
    i=p->gcparaco1[n][0];
    j=p->gcparaco1[n][1];
    k=p->gcparaco1[n][2];
	
	aa=bb=cc=0;
	
	if(p->gcparaco1[n][3]==3 || p->gcparaco1[n][4]==3)
	bb=-1;
	
	if(p->gcparaco1[n][3]==2 || p->gcparaco1[n][4]==2)
	bb=1;
	
	if(p->gcparaco1[n][3]==5 || p->gcparaco1[n][4]==5)
	cc=-1;
	
	if(p->gcparaco1[n][3]==6 || p->gcparaco1[n][4]==6)
	cc=1;
	
	sidesum= fabs(aa) + fabs(bb) + fabs(cc);
		
		val = f(i-1,j,k);
		factor = 1.0/double(p->gcparaco1[n][5]);
        
        denom = 1.0e20;
		
		if(double(p->gcparaco1[n][5])==1)
		denom = 1.0;
		
		if(double(p->gcparaco1[n][5])==2)
		denom = 2.0;
		
		if(double(p->gcparaco1[n][5])==3)
		denom = 3.0;
		
		if(sidesum==1)
		{
			if(bb==-1)
			{
			eta(i-1,j,k-1) += 0.125*factor*val;
			eta(i-1,j,k)   += 0.125*factor*val;
			}
			
			if(bb==1)
			{
			eta(i-1,j-1,k-1) += 0.125*factor*val;
			eta(i-1,j-1,k)   += 0.125*factor*val;
			}
			
			if(cc==-1)
			{
			eta(i-1,j,k) 	+= 0.125*factor*val;
			eta(i-1,j-1,k)   += 0.125*factor*val;
			}
			
			if(cc==1)
			{
			eta(i-1,j,k-1) += 0.125*factor*val;
			eta(i-1,j-1,k-1) += 0.125*factor*val;
			}
		}
		
		if(sidesum==2)
		{
			if(bb==-1 && cc==-1)
			eta(i-1,j,k) += 0.125*val/denom;
			
			if(bb==-1 && cc==1)
			eta(i-1,j,k-1) += 0.125*val/denom;
			
			if(bb==1 && cc==-1)
			eta(i-1,j-1,k) += 0.125*val/denom;
			
			if(bb==1 && cc==1)
			eta(i-1,j-1,k-1) += 0.125*val/denom;
		}
    }
	
	// 4
	for(n=0;n<p->gcparaco4_count;++n)
    {
    i=p->gcparaco4[n][0];
    j=p->gcparaco4[n][1];
    k=p->gcparaco4[n][2];
	
	aa=bb=cc=0;
	
	if(p->gcparaco4[n][3]==3 || p->gcparaco4[n][4]==3)
	bb=-1;
	
	if(p->gcparaco4[n][3]==2 || p->gcparaco4[n][4]==2)
	bb=1;
	
	if(p->gcparaco4[n][3]==5 || p->gcparaco4[n][4]==5)
	cc=-1;
	
	if(p->gcparaco4[n][3]==6 || p->gcparaco4[n][4]==6)
	cc=1;
	
	sidesum= fabs(aa) + fabs(bb) + fabs(cc);
	
		val = f(i+1,j,k);
		factor = 1.0/double(p->gcparaco4[n][5]);
		
        denom = 1.0e20;
        
		if(double(p->gcparaco4[n][5])==1)
		denom = 1.0;
		
		if(double(p->gcparaco4[n][5])==2)
		denom = 2.0;
		
		if(double(p->gcparaco4[n][5])==3)
		denom = 3.0;
		
		
		if(sidesum==1)
		{
			if(bb==-1)
			{
			eta(i,j,k-1) += 0.125*factor*val;
			eta(i,j,k)   += 0.125*factor*val;
			}
			
			if(bb==1)
			{
			eta(i,j-1,k-1) += 0.125*factor*val;
			eta(i,j-1,k)   += 0.125*factor*val;
			}
			
			if(cc==-1)
			{
			eta(i,j,k) 		+= 0.125*factor*val;
			eta(i,j-1,k)    += 0.125*factor*val;
			}
			
			if(cc==1)
			{
			eta(i,j,k-1) 	+= 0.125*factor*val;
			eta(i,j-1,k-1)  += 0.125*factor*val;
			}
		}
		
		if(sidesum==2)
		{
			if(bb==-1 && cc==-1)
			eta(i,j,k) += 0.125*val/denom;
			
			if(bb==-1 && cc==1)
			eta(i,j,k-1) += 0.125*val/denom;
			
			if(bb==1 && cc==-1)
			eta(i,j-1,k) += 0.125*val/denom;
			
			if(bb==1 && cc==1)
			eta(i,j-1,k-1) += 0.125*val/denom;
		}
    }
	
	
	// 3
	for(n=0;n<p->gcparaco3_count;++n)
    {
    i=p->gcparaco3[n][0];
    j=p->gcparaco3[n][1];
    k=p->gcparaco3[n][2];
	
	aa=bb=cc=0;
	
	if(p->gcparaco3[n][3]==1 || p->gcparaco3[n][4]==1)
	aa=-1;
	
	if(p->gcparaco3[n][3]==4 || p->gcparaco3[n][4]==4)
	aa=1;
	
	if(p->gcparaco3[n][3]==5 || p->gcparaco3[n][4]==5)
	cc=-1;
	
	if(p->gcparaco3[n][3]==6 || p->gcparaco3[n][4]==6)
	cc=1;
	
	sidesum= fabs(aa) + fabs(bb) + fabs(cc);
	
		val = f(i,j-1,k);
		factor = 1.0/double(p->gcparaco3[n][5]);
		
        denom = 1.0e20;
        
		if(double(p->gcparaco3[n][5])==1)
		denom = 1.0;
		
		if(double(p->gcparaco3[n][5])==2)
		denom = 2.0;
		
		if(double(p->gcparaco3[n][5])==3)
		denom = 3.0;
		
		if(sidesum==1)
		{
			if(aa==-1)
			{
			eta(i,j-1,k-1) += 0.125*factor*val;
			eta(i,j-1,k)   += 0.125*factor*val;
			}
			
			if(aa==1)
			{
			eta(i-1,j-1,k-1) += 0.125*factor*val;
			eta(i-1,j-1,k)   += 0.125*factor*val;
			}
			
			if(cc==-1)
			{
			eta(i,j-1,k) 	+= 0.125*factor*val;
			eta(i-1,j-1,k)   += 0.125*factor*val;
			}
			
			if(cc==1)
			{
			eta(i,j-1,k-1) += 0.125*factor*val;
			eta(i-1,j-1,k-1) += 0.125*factor*val;
			}
		}
		
		if(sidesum==2)
		{
			if(aa==-1 && cc==-1)
			eta(i,j-1,k) += 0.125*val/denom;
			
			if(aa==-1 && cc==1)
			eta(i,j-1,k-1) += 0.125*val/denom;
			
			if(aa==1 && cc==-1)
			eta(i-1,j-1,k) += 0.125*val/denom;
			
			if(aa==1 && cc==1)
			eta(i-1,j-1,k-1) += 0.125*val/denom;
		}
    }
	
	// 2
	for(n=0;n<p->gcparaco2_count;++n)
    {
    i=p->gcparaco2[n][0];
    j=p->gcparaco2[n][1];
    k=p->gcparaco2[n][2];
	
	aa=bb=cc=0;
	
	if(p->gcparaco2[n][3]==1 || p->gcparaco2[n][4]==1)
	aa=-1;
	
	if(p->gcparaco2[n][3]==4 || p->gcparaco2[n][4]==4)
	aa=1;
	
	if(p->gcparaco2[n][3]==5 || p->gcparaco2[n][4]==5)
	cc=-1;
	
	if(p->gcparaco2[n][3]==6 || p->gcparaco2[n][4]==6)
	cc=1;
	
	sidesum= fabs(aa) + fabs(bb) + fabs(cc);
	
		val = f(i,j+1,k);
		factor = 1.0/double(p->gcparaco2[n][5]);
		
        denom = 1.0e20;
        
		if(double(p->gcparaco2[n][5])==1)
		denom = 1.0;
		
		if(double(p->gcparaco2[n][5])==2)
		denom = 2.0;
		
		if(double(p->gcparaco2[n][5])==3)
		denom = 3.0;
		
		
		if(sidesum==1)
		{
			if(aa==-1)
			{
			eta(i,j,k-1) += 0.125*factor*val;
			eta(i,j,k)   += 0.125*factor*val;
			}
			
			if(aa==1)
			{
			eta(i-1,j,k-1) += 0.125*factor*val;
			eta(i-1,j,k)   += 0.125*factor*val;
			}
			
			if(cc==-1)
			{
			eta(i,j,k) 		+= 0.125*factor*val;
			eta(i-1,j,k)    += 0.125*factor*val;
			}
			
			if(cc==1)
			{
			eta(i,j,k-1) += 0.125*factor*val;
			eta(i-1,j,k-1) += 0.125*factor*val;
			}
		}
		
		if(sidesum==2)
		{
			if(aa==-1 && cc==-1)
			eta(i,j,k) += 0.125*val/denom;
			
			if(aa==-1 && cc==1)
			eta(i,j,k-1) += 0.125*val/denom;
			
			if(aa==1 && cc==-1)
			eta(i-1,j,k) += 0.125*val/denom;
			
			if(aa==1 && cc==1)
			eta(i-1,j,k-1) += 0.125*val/denom;
		}
    }
	
	
	// 5
	for(n=0;n<p->gcparaco5_count;++n)
    {
    i=p->gcparaco5[n][0];
    j=p->gcparaco5[n][1];
    k=p->gcparaco5[n][2];
	
	aa=bb=cc=0;
	
	if(p->gcparaco5[n][3]==1 || p->gcparaco5[n][4]==1)
	aa=-1;
	
	if(p->gcparaco5[n][3]==4 || p->gcparaco5[n][4]==4)
	aa=1;
	
	if(p->gcparaco5[n][3]==3 || p->gcparaco5[n][4]==3)
	bb=-1;
	
	if(p->gcparaco5[n][3]==2 || p->gcparaco5[n][4]==2)
	bb=1;
	
	sidesum= fabs(aa) + fabs(bb) + fabs(cc);
	
		val = f(i,j,k-1);
		factor = 1.0/double(p->gcparaco5[n][5]);
		
        denom = 1.0e20;
        
		if(double(p->gcparaco5[n][5])==1)
		denom = 1.0;
		
		if(double(p->gcparaco5[n][5])==2)
		denom = 2.0;
		
		if(double(p->gcparaco5[n][5])==3)
		denom = 3.0;
		
		if(sidesum==1)
		{
			if(aa==-1)
			{
			eta(i,j-1,k-1) 	+= 0.125*factor*val;
			eta(i,j,k-1)   += 0.125*factor*val;
			}
			
			if(aa==1)
			{
			eta(i-1,j-1,k-1) += 0.125*factor*val;
			eta(i-1,j,k-1)   += 0.125*factor*val;
			}
			
			if(bb==-1)
			{
			eta(i,j,k-1) 	+= 0.125*factor*val;
			eta(i-1,j,k-1)   += 0.125*factor*val;
			}
			
			if(bb==1)
			{
			eta(i,j-1,k-1) += 0.125*factor*val;
			eta(i-1,j-1,k-1) += 0.125*factor*val;
			}
			
		}
		
		if(sidesum==2)
		{
			if(aa==-1 && bb==-1)
			eta(i,j,k-1) += 0.125*val/denom;
			
			if(aa==-1 && bb==1)
			eta(i,j-1,k-1) += 0.125*val/denom;
			
			if(aa==1 && bb==-1)
			eta(i-1,j,k-1) += 0.125*val/denom;
			
			if(aa==1 && bb==1)
			eta(i-1,j-1,k-1) += 0.125*val/denom;
		}
    }
	
	// 6
	for(n=0;n<p->gcparaco6_count;++n)
    {
    i=p->gcparaco6[n][0];
    j=p->gcparaco6[n][1];
    k=p->gcparaco6[n][2];
	
	aa=bb=cc=0;
	
	if(p->gcparaco6[n][3]==1 || p->gcparaco6[n][4]==1)
	aa=-1;
	
	if(p->gcparaco6[n][3]==4 || p->gcparaco6[n][4]==4)
	aa=1;
	
	if(p->gcparaco6[n][3]==3 || p->gcparaco6[n][4]==3)
	bb=-1;
	
	if(p->gcparaco6[n][3]==2 || p->gcparaco6[n][4]==2)
	bb=1;
	
	sidesum= fabs(aa) + fabs(bb) + fabs(cc);
		
		val = f(i,j,k+1);
		
		
		factor = 1.0/double(p->gcparaco6[n][5]);
		
        denom = 1.0e20;
        
		if(double(p->gcparaco6[n][5])==1)
		denom = 1.0;
		
		if(double(p->gcparaco6[n][5])==2)
		denom = 2.0;
		
		if(double(p->gcparaco6[n][5])==3)
		denom = 3.0;
		
		if(sidesum==1)
		{
			if(aa==-1)
			{
			eta(i,j-1,k) += 0.125*factor*val;
			eta(i,j,k)   += 0.125*factor*val;
			}
			
			if(aa==1)
			{
			eta(i-1,j-1,k) += 0.125*factor*val;
			eta(i-1,j,k)   += 0.125*factor*val;
			}
			
			if(bb==-1)
			{
			eta(i,j,k) 	   += 0.125*factor*val;
			eta(i-1,j,k)   += 0.125*factor*val;
			}
			
			if(bb==1)
			{
			eta(i,j-1,k) += 0.125*factor*val;
			eta(i-1,j-1,k) += 0.125*factor*val;
			}
		}
		
		if(sidesum==2)
		{
			if(aa==-1 && bb==-1)
			eta(i,j,k) += 0.125*val/denom;
			
			if(aa==-1 && bb==1)
			eta(i,j-1,k) += 0.125*val/denom;
			
			if(aa==1 && bb==-1)
			eta(i-1,j,k) += 0.125*val/denom;
			
			if(aa==1 && bb==1)
			eta(i-1,j-1,k) += 0.125*val/denom;
		}
    }
	
	
	
	// DGC
	int a1,a2,b1,b2,c1,c2;
	int acheck,bcheck,ccheck;
	double val1,val2,val3,val4,val5,val6;

	
	for(n=0;n<p->dgc4_count;++n)
	{
	i=p->dgc4[n][0];
    j=p->dgc4[n][1];
    k=p->dgc4[n][2];
	
		a1=a2=b1=b2=c1=c2=0;
		val1=val2=val3=val4=val5=val6=0.0;
		acheck=bcheck=ccheck=0;
		aa=bb=cc=0;
		
		for(q=0;q<p->dgc4[n][3];++q)
		{
				if(p->dgc4[n][4+q]==1)
				{
				a1=-1;
				val1=f(i-1,j,k);
				++acheck;
				}

				if(p->dgc4[n][4+q]==2)
				{
				b2=1;
				val2=f(i,j+1,k);
				++bcheck;
				}

				if(p->dgc4[n][4+q]==3)
				{
				b1=-1;
				val3=f(i,j-1,k);
				++bcheck;
				}

				if(p->dgc4[n][4+q]==4)
				{
				a2=1;
				val4=f(i+1,j,k);
				++acheck;
				}

				if(p->dgc4[n][4+q]==5)
				{
				c1=-1;
				val5=f(i,j,k-1);
				++ccheck;
				}

				if(p->dgc4[n][4+q]==6)
				{
				c2=1;
				val6=f(i,j,k+1);
				++ccheck;
				}
		}
		
			if(p->dgc4[n][3]==2)
			{
				if(a1==0 && a2==0)
				aa=-1;
				
				if(b1==0 && b2==0)
				bb=-1;
				
				if(c1==0 && c2==0)
				cc=-1;
				
				val = f(i+a1+a2,j+b1+b2,k+c1+c2);
				
				eta(i+a1+aa,j+b1+bb,k+c1+cc) += 0.125*val;
				eta(i+a1,j+b1,k+c1) += 0.125*val;
			}
			
			if(p->dgc4[n][3]==3 && acheck==1 && bcheck==1 && ccheck==1)
			{
			// 3 regular corners
	
				// 1  xy
				val = f(i+a1+a2,j+b1+b2,k);
				
				eta(i+a1,j+b1,k-1) += 0.125*val;
				eta(i+a1,j+b1,k) += 0.125*val;	
				
				// 2 xz
				val = f(i+a1+a2,j,k+c1+c2);
				
				eta(i+a1,j-1,k+c1) += 0.125*val;
				eta(i+a1,j,k+c1) += 0.125*val;
				
				// 3 yz
				val = f(i,j+b1+b2,k+c1+c2);
				
				eta(i-1,j+b1,k+c1) += 0.125*val;
				eta(i,j+b1,k+c1) += 0.125*val;
					
				
				// diagonal corner	
				val = f(i+a1+a2,j+b1+b2,k+c1+c2);
				
				eta(i+a1,j+b1,k+c1) += 0.125*val;
			}
			
			
			if(p->dgc4[n][3]==3 && (acheck==2 || bcheck==2 || ccheck==2))
			{
				
				// 1   xy
				if(c1==0 && c2==0 && bcheck==2 && a1!=0)
				{
				val = 0.5*(val1+val3);
				
				eta(i+a1,j+b1,k-1) += 0.125*val;
				eta(i+a1,j+b1,k) += 0.125*val;
				
				val = 0.5*(val1+val2);
			
				eta(i+a1,j,k-1) += 0.125*val;
				eta(i+a1,j,k) += 0.125*val;				
				}
				
				if(c1==0 && c2==0 && bcheck==2 && a2!=0)
				{
				val = 0.5*(val4+val3);
				
				eta(i+a1,j+b1,k-1) += 0.125*val;
				eta(i+a1,j+b1,k) += 0.125*val;
				
				val = 0.5*(val4+val2);
			
				eta(i+a1,j,k-1) += 0.125*val;
				eta(i+a1,j,k) += 0.125*val;				
				}
				
				if(c1==0 && c2==0 && acheck==2 && b1!=0)
				{
				val = 0.5*(val1+val3);
			
				eta(i+a1,j+b1,k-1) += 0.125*val;
				eta(i+a1,j+b1,k) += 0.125*val;
				
				val = 0.5*(val4+val3);
			
				eta(i,j+b1,k-1) += 0.125*val;
				eta(i,j+b1,k) += 0.125*val;				
				}
				
				if(c1==0 && c2==0 && acheck==2 && b2!=0)
				{
				val = 0.5*(val1+val2);
			
				eta(i+a1,j+b1,k-1) += 0.125*val;
				eta(i+a1,j+b1,k) += 0.125*val;
				
				val = 0.5*(val4+val2);
			
				eta(i,j+b1,k-1) += 0.125*val;
				eta(i,j+b1,k) += 0.125*val;				
				}
				
				// 2 xz
				if(b1==0 && b2==0 && ccheck==2 && a1!=0)
				{
				val = 0.5*(val1+val5);
				
				eta(i+a1,j-1,k+c1) += 0.125*val;
				eta(i+a1,j,k+c1) += 0.125*val;
				
				val = 0.5*(val1+val6);
			
				eta(i+a1,j-1,k) += 0.125*val;
				eta(i+a1,j,k) += 0.125*val;				
				}
				
				if(b1==0 && b2==0 && ccheck==2 && a2!=0)
				{
				val = 0.5*(val4+val5);
				
				eta(i+a1,j-1,k+c1) += 0.125*val;
				eta(i+a1,j,k+c1) += 0.125*val;
				
				val = 0.5*(val4+val6);
			
				eta(i+a1,j-1,k) += 0.125*val;
				eta(i+a1,j,k) += 0.125*val;				
				}
				
				
				if(b1==0 && b2==0 && acheck==2 && c1!=0)
				{
				val = 0.5*(val1+val5);
			
				eta(i+a1,j-1,k+c1) += 0.125*val;
				eta(i+a1,j,k+c1) += 0.125*val;
				
				val = 0.5*(val4+val5);
			
				eta(i,j-1,k+c1) += 0.125*val;
				eta(i,j,k+c1) += 0.125*val;				
				}
				
				if(b1==0 && b2==0 && acheck==2 && c2!=0)
				{
				val = 0.5*(val1+val6);
			
				eta(i+a1,j-1,k+c1) += 0.125*val;
				eta(i+a1,j,k+c1) += 0.125*val;
				
				val = 0.5*(val4+val6);
			
				eta(i,j-1,k+c1) += 0.125*val;
				eta(i,j,k+c1) += 0.125*val;				
				}
				
				
				// 3 yz
				if(a1==0 && a2==0 && ccheck==2 && b1!=0)
				{
				val = 0.5*(val3+val5);
			
				eta(i-1,j+b1,k+c1) += 0.125*val;
				eta(i,j+b1,k+c1) += 0.125*val;
				
				val = 0.5*(val3+val6);
			
				eta(i-1,j+b1,k) += 0.125*val;
				eta(i,j+b1,k) += 0.125*val;				
				}
				
				if(a1==0 && a2==0 && ccheck==2 && b2!=0)
				{
				val = 0.5*(val2+val5);
			
				eta(i-1,j+b1,k+c1) += 0.125*val;
				eta(i,j+b1,k+c1) += 0.125*val;
				
				val = 0.5*(val2+val6);
			
				eta(i-1,j+b1,k) += 0.125*val;
				eta(i,j+b1,k) += 0.125*val;				
				}
				
				if(a1==0 && a2==0 && bcheck==2 && c1!=0)
				{
				val = 0.5*(val3+val5);
			
				eta(i-1,j+b1,k+c1) += 0.125*val;
				eta(i,j+b1,k+c1) += 0.125*val;
				
				val = 0.5*(val2+val5);
			
				eta(i-1,j,k+c1) += 0.125*val;
				eta(i,j,k+c1) += 0.125*val;				
				}
				
				if(a1==0 && a2==0 && bcheck==2 && c2!=0)
				{
				val = 0.5*(val3+val6);
			
				eta(i-1,j+b1,k+c1) += 0.125*val;
				eta(i,j+b1,k+c1) += 0.125*val;
				
				val = 0.5*(val2+val6);
			
				eta(i-1,j,k+c1) += 0.125*val;
				eta(i,j,k+c1) += 0.125*val;				
				}
			}
			
			
			if(p->dgc4[n][3]==4 && (acheck==2 || bcheck==2 || ccheck==2))
			{
				val1=0.125*f(i,j,k);
				
				if(acheck==2)
				{
					if(b1!=0 && c1!=0) 
					{
					eta(i-1,j-1,k-1) += 4.0*val1;
					eta(i,j-1,k-1) += 4.0*val1;
					eta(i-1,j-1,k) += val1;
					eta(i,j-1,k) += val1;
					eta(i,j,k-1) += val1;
					eta(i-1,j,k-1) += val1;
					}

					if(b1!=0 && c2!=0) 
					{
					eta(i-1,j-1,k) += 4.0*val1;
					eta(i,j-1,k) += 4.0*val1;
					eta(i-1,j,k) += val1;
					eta(i,j,k) += val1;
					eta(i-1,j-1,k-1) += val1;
					eta(i,j-1,k-1) += val1;
					}

					if(b2!=0 && c1!=0) 
					{
					eta(i-1,j,k-1) += 4.0*val1;
					eta(i,j,k-1) += 4.0*val1;
					eta(i-1,j-1,k-1) += val1;
					eta(i,j-1,k-1) += val1;
					eta(i-1,j,k) += val1;
					eta(i,j,k) += val1;
					}

					if(b2!=0 && c2!=0) 
					{
					eta(i,j,k) += 4.0*val1;
					eta(i-1,j,k) += 4.0*val1;
					eta(i,j-1,k) += val1;
					eta(i-1,j-1,k) += val1;
					eta(i-1,j,k-1) += val1;
					eta(i,j,k-1) += val1;
					}
				}

				if(bcheck==2)
				{
					if(a1!=0 && c1!=0) 
					{
					eta(i-1,j-1,k-1) += 4.0*val1;
					eta(i-1,j,k-1) += 4.0*val1;
					eta(i,j-1,k-1) += val1;
					eta(i,j,k-1) += val1;
					eta(i-1,j-1,k) += val1;
					eta(i-1,j,k) += val1;
					}

					if(a1!=0 && c2!=0)
					{
					eta(i-1,j-1,k) += 4.0*val1;
					eta(i-1,j,k) += 4.0*val1;
					eta(i-1,j-1,k-1) += val1;
					eta(i-1,j,k-1) += val1;
					eta(i,j-1,k) += val1;
					eta(i,j,k) += val1;
					}

					if(a2!=0 && c1!=0) 
					{
					eta(i,j-1,k) += val1;
					eta(i,j,k) += val1;
					eta(i,j-1,k-1) += 4.0*val1;
					eta(i,j,k-1) += 4.0*val1;
					eta(i-1,j-1,k-1) += val1;
					eta(i-1,j,k-1) += val1;
					}

					if(a2!=0 && c2!=0)
					{
					eta(i,j-1,k-1) += val1;
					eta(i,j,k-1) += val1;
					eta(i,j-1,k) += 4.0*val1;
					eta(i,j,k) += 4.0*val1;
					eta(i-1,j-1,k) += val1;
					eta(i-1,j,k) += val1;
					}
				}


				if(ccheck==2)
				{
					if(a1!=0 && b1!=0) 
					{
					eta(i,j-1,k-1) += 4.0*val1;
					eta(i,j-1,k) += 4.0*val1;
					eta(i-1,j-1,k-1) += val1;
					eta(i-1,j-1,k) += val1;
					eta(i,j,k-1) += val1;
					eta(i,j,k) += val1;
					}

					if(a1!=0 && b2!=0) 
					{
					eta(i,j,k-1) += 4.0*val1;
					eta(i,j,k) += 4.0*val1;
					eta(i,j-1,k-1) += val1;
					eta(i,j-1,k) += val1;
					eta(i-1,j,k-1) += val1;
					eta(i-1,j,k) += val1;
					}

					if(a2!=0 && b1!=0) 
					{
					eta(i-1,j,k-1) += 4.0*val1;
					eta(i-1,j,k) += 4.0*val1;
					eta(i-1,j-1,k-1) += val1;
					eta(i-1,j-1,k) += val1;
					eta(i,j,k-1) += val1;
					eta(i,j,k) += val1;
					}

					if(a2!=0 && b2!=0) 
					{
					eta(i-1,j-1,k-1) += 4.0*val1;
					eta(i-1,j-1,k) += 4.0*val1;
					eta(i-1,j,k-1) += val1;
					eta(i-1,j,k) += val1;
					eta(i,j-1,k-1) += val1;
					eta(i,j-1,k) += val1;
					}
				}
			}
	}
	
pip=0;
}
