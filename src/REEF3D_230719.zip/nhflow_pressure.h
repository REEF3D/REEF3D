/*--------------------------------------------------------------------
REEF3D
Copyright 2008-2023 Hans Bihs

This file is part of REEF3D.

REEF3D is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTIBILITY or
FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, see <http://www.gnu.org/licenses/>.
--------------------------------------------------------------------
Author: Hans Bihs
--------------------------------------------------------------------*/

class lexer;
class fdm_nhf;
class ghostcell;
class ioflow;
class solver;
class field;
class slice;

using namespace std;

#ifndef NHFLOW_PRESSURE_H_
#define NHFLOW_PRESSURE_H_

class nhflow_pressure
{
public:

	virtual void start(lexer*,fdm_nhf*,solver*,ghostcell*,ioflow*,slice&,double*,double*,double*,double)=0;
	virtual void upgrad(lexer*,fdm_nhf*)=0;
	virtual void vpgrad(lexer*,fdm_nhf*)=0;
	virtual void wpgrad(lexer*,fdm_nhf*)=0;
    virtual void ucorr(lexer*,fdm_nhf*,slice&,double*,double)=0;
	virtual void vcorr(lexer*,fdm_nhf*,slice&,double*,double)=0;
	virtual void wcorr(lexer*,fdm_nhf*,slice&,double*,double)=0;
};

#endif
